import { useState } from "react";

const DS = {
  ink: "#060608", parchment: "#F4F1E8", parchmentDark: "#F0EDE4",
  gold: "#C4900A", muted: "#6B6A6D", border: "#DDD9CC",
};

const ALL_CATEGORIES = {
  agencies: { icon: "◆", label: "Agencies", subs: ["Performance Marketing","Mobile App Marketing","SEO & Search Marketing","Affiliate Marketing","Growth & Demand Gen","E-commerce Marketing","Creative & Branding","Content Marketing","Video Production","Photography & Production","Social Media Marketing","Influencer Marketing","PR & Communications","Public Affairs","Media Planning & Buying","Programmatic & Ad Tech","OOH & Experiential","Martech & Analytics","CRM & Retention","Marketing Automation","Healthcare Marketing","Real Estate Marketing","B2B Marketing","Sustainability Marketing","Gaming & Esports","Luxury Marketing"] },
  creators: { icon: "◉", label: "Creators", subs: ["Instagram Creators","YouTube Creators","LinkedIn Creators","Podcast Creators","Short-form Video","Newsletter & Blog","Twitter / X","Finance Creators","Tech Creators","Fashion & Style","Beauty & Skincare","Food & Beverage","Health & Fitness","Travel Creators","Business & Entrepreneurship","Education & Learning","Parenting & Family","Comedy & Entertainment","Gaming Creators","Regional Language Creators"] },
  professionals: { icon: "◈", label: "Professionals", subs: ["Fractional CMO","Brand Strategist","Growth Advisor","Performance Consultant","Content Strategist","Media Planner","Marketing Technologist","SEO Consultant","CRM Consultant","PR Consultant","Market Research","Creative Director","Copywriter","UX Strategist","Data & Analytics","Influencer Consultant","Marketing Trainer","Interim Marketing Manager"] },
  serviceProviders: { icon: "◫", label: "Service Providers", subs: ["Research & Insights","Translation & Localisation","Audio & Music Production","Animation Studios","Events & Activations","Print & Production","MarTech Vendors","Talent Management","Media Owners & Publishers","Data Providers"] },
  brands: { icon: "◇", label: "Brands", subs: ["D2C & Direct-to-Consumer","FMCG","Fintech & BFSI","Consumer Technology","EdTech","HealthTech & Healthcare","E-commerce Platforms","OTT & Media","Automotive","Real Estate & PropTech","Fashion & Apparel","Food & Beverage","Travel & Hospitality","B2B & Enterprise","Gaming","Retail","Non-Profit","Government & PSUs"] },
};

const CITIES = ["Mumbai","Delhi NCR","Bengaluru","Hyderabad","Chennai","Pune","Kolkata","Ahmedabad","Gurugram","Noida","Jaipur","Chandigarh","Kochi","Indore","Remote / Pan-India"];

const PAGES = {
  homepage: "01 — Homepage",
  "listing-quick": "02 — Quick Capture & Auth",
  "listing-dashboard": "03 — Provider Dashboard",
  "listing-verification": "04 — Verification Application",
  "category-page": "05 — Category Listing Page",
  "empty-category": "06 — Empty Category State",
  "profile-page": "07 — Provider Profile",
  "client-record": "08 — Client Record (Glassdoor)",
  "brand-membership": "09 — Brand Membership",
  "admin": "10 — Admin Dashboard",
};

const BACKEND = {
  homepage: [
    { role: "Next.js SSR", action: "Page rendered server-side on every request. Meta tags, JSON-LD, Open Graph injected before HTML is sent. Lighthouse SEO: 100." },
    { role: "Supabase Query", action: "4 parallel queries: provider count, verified count, brand member count, recent Client Records. Cached 60s via Redis. Result: stats block populates in <50ms." },
    { role: "Search (Real-time)", action: "User types → debounced 300ms → Postgres full-text search on name, bio, services, city. Returns verified first via ORDER BY verified DESC, created_at DESC. Hardcoded. Non-negotiable." },
    { role: "Nightly Scraper", action: "Cron job at 2am IST. Pulls Clutch, GoodFirms, LinkedIn Company API. Creates shadow listings for unclaimed providers. Sends invitation email via Resend to found email addresses." },
    { role: "Empty State Handler", action: "If category has 0 listings: shows 'Our scouts are working' message + email capture. Waitlist stored in Supabase waitlist table. Automated email sent when first listing appears in that category." },
    { role: "SEO / AI Search", action: "IndexNow API pinged when new provider lists. JSON-LD breadcrumb, Organization, LocalBusiness schemas on every page. Sitemap.xml auto-regenerated. robots.txt allows all except /admin." },
  ],
  "listing-quick": [
    { role: "Supabase Auth", action: "Google OAuth → Google returns user object. Supabase creates auth.users row. DB trigger fires: creates user_profiles row with name, email, avatar_url from OAuth data." },
    { role: "LinkedIn OAuth", action: "LinkedIn OIDC → returns name, email, headline, current company. System pre-fills agency name from company field. City pre-filled from location field if available." },
    { role: "Quick Capture API", action: "POST /api/providers. 3 fields: name, type, city. Slug auto-generated: slugify(name) + '-' + slugify(city) + '-' + timestamp(). Profile live in Supabase in <500ms." },
    { role: "Scraper Match", action: "On creation: system checks if this name+city combination exists in scraped_providers table (from Clutch/LinkedIn). If match >85% confidence: auto-populates services, team_size, founding_year, website. User sees pre-filled dashboard." },
    { role: "Resend Email", action: "Confirmation email sent within 60 seconds. Template: 'You are on Few Found. Your profile: [link]. One next step: complete your profile.' Personalised with their name from OAuth." },
    { role: "ISR", action: "Next.js Incremental Static Regeneration. New profile page generated and cached. City page and category page regenerated to include new listing. Sitemap updated." },
  ],
};

const QA = {
  homepage: [
    { q: "Hero wordmark: FEW (left-aligned) / gold rule / FOUND. On mobile: should the wordmark be centred or remain left-aligned?", opts: ["Left-aligned on all screens", "Centre on mobile only", "Centre always"] },
    { q: "The FOMO ticker shows live activity stats. Should this be real-time (WebSocket) or static text updated hourly?", opts: ["Real-time WebSocket", "Hourly static refresh", "Static — no update"] },
    { q: "Stats row shows 4 numbers including Client Records. Should Client Records stat be visible before the feature launches or hidden until there is data?", opts: ["Show from day 1 as 0", "Hide until 10+ records", "Replace with different stat"] },
    { q: "The 'Verify Claims' section shows example verified/unverified claims. Should this use real data from the first verified provider or remain illustrative?", opts: ["Real data from first verified", "Illustrative always", "Toggle between both"] },
    { q: "Category grid shows all 5 types with subcategories. On mobile this becomes very long. Should subcategories be hidden on mobile with a Show more?", opts: ["Show all on mobile", "Collapse on mobile", "Show only 3 sub-items on mobile"] },
  ],
  "listing-quick": [
    { q: "Quick capture: 3 fields (name, type, city) OR 2 fields (name, type) and ask city in dashboard?", opts: ["3 fields including city", "2 fields only", "1 field (name) then type selector"] },
    { q: "Social login: Google + LinkedIn. Add WhatsApp OTP for creators who primarily use WhatsApp?", opts: ["Google + LinkedIn only", "Add WhatsApp OTP", "Add all three"] },
    { q: "After listing: go to dashboard immediately OR show a full-screen success message first?", opts: ["Dashboard immediately", "Success screen then dashboard", "Success screen with confetti"] },
  ],
};

function Wordmark({ dark = false, size = "md" }) {
  const sizes = { sm: [14, 14, 1], md: [22, 26, 1.5], lg: [48, 60, 2], hero: [72, 88, 3] };
  const [few, found, rule] = sizes[size] || sizes.md;
  const color = dark ? DS.parchment : DS.ink;
  return (
    <div style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
      <span style={{ fontFamily: "Georgia,serif", fontSize: few, fontWeight: 700, letterSpacing: "0.35em", color }}> FEW</span>
      <div style={{ height: rule, background: DS.gold, margin: "4px 0" }} />
      <span style={{ fontFamily: "Georgia,serif", fontSize: found, fontWeight: 900, letterSpacing: "0.35em", color }}>FOUND</span>
    </div>
  );
}

function Badge({ verified }) {
  return verified
    ? <span style={{ background: DS.ink, color: DS.parchment, fontSize: 9, fontWeight: 700, letterSpacing: "0.1em", padding: "3px 8px" }}>✓ VERIFIED</span>
    : <span style={{ border: `1px solid ${DS.border}`, color: DS.muted, fontSize: 9, letterSpacing: "0.1em", padding: "3px 8px" }}>LISTED</span>;
}

function EmptyState({ category, city }) {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  return (
    <div style={{ border: `1px solid ${DS.border}`, padding: 40, textAlign: "center", background: DS.parchmentDark }}>
      <div style={{ fontSize: 28, color: DS.muted, marginBottom: 16 }}>◎</div>
      <div style={{ fontFamily: "Georgia,serif", fontSize: 20, color: DS.ink, marginBottom: 8 }}>Our scouts are working on this.</div>
      <div style={{ fontSize: 12, color: DS.muted, maxWidth: 380, margin: "0 auto 6px", lineHeight: 1.7 }}>
        We are identifying and inviting verified {category} providers{city ? ` in ${city}` : ""}. Our system is running background verification in this category.
      </div>
      <div style={{ fontSize: 10, color: DS.gold, fontStyle: "italic", marginBottom: 20 }}>● Background verification in progress</div>
      {!done ? (
        <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 20 }}>
          <input type="email" placeholder="your@email.com" value={email} onChange={e => setEmail(e.target.value)}
            style={{ border: `1px solid ${DS.border}`, padding: "8px 14px", fontSize: 12, background: DS.parchment, color: DS.ink, outline: "none", width: 200 }} />
          <button onClick={() => setDone(true)} style={{ background: DS.ink, color: DS.parchment, border: "none", padding: "8px 16px", fontSize: 11, cursor: "pointer", letterSpacing: "0.08em", fontWeight: 700 }}>NOTIFY ME</button>
        </div>
      ) : (
        <div style={{ fontSize: 12, color: DS.muted, marginBottom: 20 }}>✓ We will email you when the first verified listing appears here.</div>
      )}
      <div style={{ paddingTop: 20, borderTop: `1px solid ${DS.border}` }}>
        <div style={{ fontSize: 11, color: DS.muted, marginBottom: 10 }}>Be the first verified {category} provider listed here.</div>
        <button style={{ border: `1px solid ${DS.ink}`, background: "transparent", color: DS.ink, padding: "8px 16px", fontSize: 11, cursor: "pointer", letterSpacing: "0.06em" }}>
          CLAIM THIS POSITION →
        </button>
      </div>
    </div>
  );
}

function ProviderCard({ name, cat, city, verified, bio, services, yr, size }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ border: `1px solid ${hov ? DS.ink : DS.border}`, padding: 20, background: DS.parchment, cursor: "pointer", transition: "border-color 0.15s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div>
          <div style={{ fontFamily: "Georgia,serif", fontSize: 16, color: DS.ink, fontWeight: 600 }}>{name}</div>
          <div style={{ fontSize: 10, color: DS.muted, marginTop: 2, letterSpacing: "0.04em" }}>{cat} · {city}</div>
        </div>
        <Badge verified={verified} />
      </div>
      {bio && <div style={{ fontSize: 11, color: DS.muted, lineHeight: 1.6, marginBottom: 10 }}>{bio}</div>}
      <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginBottom: 10 }}>
        {services?.slice(0, 3).map(s => <span key={s} style={{ border: `1px solid ${DS.border}`, fontSize: 10, padding: "2px 7px", color: DS.ink }}>{s}</span>)}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: DS.muted }}>
        <span>{yr && `Est. ${yr}`}{size && ` · ${size}`}</span>
        <span>View profile →</span>
      </div>
    </div>
  );
}

// ── HOMEPAGE ──────────────────────────────────────────────────────
function Homepage() {
  const [sq, setSq] = useState("");
  const [showAll, setShowAll] = useState({});
  const toggleAll = key => setShowAll(s => ({ ...s, [key]: !s[key] }));

  const providers = [
    { name: "Meridian Performance", cat: "Performance Marketing", city: "Mumbai", verified: true, yr: 2017, size: "25-50", services: ["Paid Search", "Programmatic", "Affiliate"], bio: "Full-funnel performance agency scaling D2C and fintech brands." },
    { name: "Northlight Creative", cat: "Creative & Branding", city: "Mumbai", verified: true, yr: 2015, size: "15-25", services: ["Brand Strategy", "Visual Identity", "Creative"], bio: "Brand strategy agency building category-defining consumer brands." },
    { name: "Priya Sharma", cat: "Finance Creators", city: "Delhi NCR", verified: true, yr: null, size: null, services: ["Instagram", "YouTube", "Brand Deals"], bio: "Personal finance creator. 280K verified Instagram audience." },
    { name: "Strata Digital", cat: "App Marketing", city: "Bengaluru", verified: true, yr: 2018, size: "25-50", services: ["UA Campaigns", "MMP", "Retargeting"], bio: "Mobile app growth specialists. AppsFlyer & Adjust certified." },
    { name: "GroundUp Agency", cat: "Social Media", city: "Delhi NCR", verified: false, yr: 2021, size: "6-10", services: ["Instagram", "Paid Social", "Content"], bio: null },
    { name: "Ravi Mehta", cat: "Fractional CMO", city: "Bengaluru", verified: false, yr: null, size: null, services: ["Marketing Strategy", "Team Building", "GTM"], bio: null },
  ];

  return (
    <div style={{ background: DS.parchment, minHeight: "100vh" }}>

      {/* NAV */}
      <nav style={{ background: DS.parchment, borderBottom: `1px solid ${DS.border}`, padding: "12px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 10 }}>
        <Wordmark size="sm" />
        <div style={{ display: "flex", gap: 24, fontSize: 12, color: DS.muted }}>
          {Object.values(ALL_CATEGORIES).map(c => <span key={c.label} style={{ cursor: "pointer" }}>{c.label}</span>)}
          <span style={{ cursor: "pointer" }}>How it works</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button style={{ border: `1px solid ${DS.ink}`, background: "transparent", color: DS.ink, padding: "7px 14px", fontSize: 11, cursor: "pointer", letterSpacing: "0.06em" }}>FOR BRANDS</button>
          <button style={{ background: DS.ink, color: DS.parchment, border: "none", padding: "7px 14px", fontSize: 11, cursor: "pointer", fontWeight: 700, letterSpacing: "0.06em" }}>LIST FREE →</button>
        </div>
      </nav>

      {/* HERO */}
      <section style={{ background: DS.ink, color: DS.parchment, padding: "72px 32px 80px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ marginBottom: 28 }}>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 72, fontWeight: 700, letterSpacing: "0.35em", lineHeight: 1 }}>FEW</div>
            <div style={{ height: 3, background: DS.gold, width: 440, margin: "8px 0" }} />
            <div style={{ fontFamily: "Georgia,serif", fontSize: 88, fontWeight: 900, letterSpacing: "0.35em", lineHeight: 1 }}>FOUND</div>
          </div>
          <div style={{ fontFamily: "Georgia,serif", fontSize: 21, color: "rgba(244,241,232,0.8)", maxWidth: 560, marginBottom: 10, lineHeight: 1.5 }}>
            India's trust layer for marketing service providers.
          </div>
          <div style={{ fontSize: 13, color: "rgba(244,241,232,0.5)", maxWidth: 500, marginBottom: 36, lineHeight: 1.75 }}>
            The brands making the best hiring decisions are already here. The question is whether they will find you before they find someone else.
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 8, maxWidth: 880 }}>
            {Object.entries(ALL_CATEGORIES).map(([k, c]) => (
              <div key={k} style={{ border: "1px solid rgba(244,241,232,0.12)", padding: "14px 12px", cursor: "pointer" }}>
                <div style={{ fontSize: 20, color: "rgba(244,241,232,0.3)", marginBottom: 8 }}>{c.icon}</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: DS.parchment, marginBottom: 4, letterSpacing: "0.04em" }}>
                  List as {c.label === "Service Providers" ? "Vendor" : c.label.replace(/s$/, "")} →
                </div>
                <div style={{ fontSize: 9, color: DS.gold, fontStyle: "italic", lineHeight: 1.5 }}>
                  {k === "agencies" && "Verified agencies in brand shortlists now."}
                  {k === "creators" && "Brands check verified status before briefing."}
                  {k === "professionals" && "Most searched category on the platform."}
                  {k === "serviceProviders" && "Agencies searching for verified vendors."}
                  {k === "brands" && "Agencies read your Client Record before pitching."}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TICKER */}
      <div style={{ background: "#0d0d0f", padding: "9px 32px" }}>
        <div style={{ fontSize: 9, color: "rgba(244,241,232,0.3)", letterSpacing: "0.12em", textAlign: "center" }}>
          ● BRAND MEMBERS SHORTLISTING VERIFIED PROVIDERS NOW &nbsp;·&nbsp; LISTED-ONLY EXCLUDED FROM SHORTLISTS &nbsp;·&nbsp; 3 VERIFICATION ASSESSMENTS IN PROGRESS &nbsp;·&nbsp; 12 CLIENT RECORDS FILED THIS WEEK
        </div>
      </div>

      {/* SEARCH */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "24px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 8 }}>SEARCH & VERIFY — FREE FOR EVERYONE</div>
          <div style={{ display: "flex" }}>
            <select style={{ border: `1px solid ${DS.border}`, borderRight: "none", padding: "11px 14px", fontSize: 12, color: DS.ink, background: DS.parchmentDark, outline: "none" }}>
              <option>All types</option>
              {Object.values(ALL_CATEGORIES).map(c => <option key={c.label}>{c.label}</option>)}
            </select>
            <select style={{ border: `1px solid ${DS.border}`, borderRight: "none", padding: "11px 14px", fontSize: 12, color: DS.ink, background: DS.parchmentDark, outline: "none" }}>
              <option>All cities</option>
              {CITIES.map(c => <option key={c}>{c}</option>)}
            </select>
            <input value={sq} onChange={e => setSq(e.target.value)} placeholder="Search by name, service, brand worked with, or category..." style={{ flex: 1, border: `1px solid ${DS.border}`, padding: "11px 14px", fontSize: 12, color: DS.ink, background: DS.parchment, outline: "none" }} />
            <button style={{ background: DS.ink, color: DS.parchment, border: "none", padding: "11px 22px", fontSize: 11, cursor: "pointer", fontWeight: 700, letterSpacing: "0.08em" }}>SEARCH</button>
          </div>
          <div style={{ fontSize: 10, color: DS.muted, marginTop: 7 }}>Brands: search any provider name to see if their claims are independently verified before taking their pitch meeting.</div>
        </div>
      </section>

      {/* STATS */}
      <section style={{ borderBottom: `1px solid ${DS.border}` }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4,1fr)" }}>
          {[
            { n: "247", l: "Providers listed across all categories" },
            { n: "38", l: "Few Found Verified — first in every search" },
            { n: "6", l: "Brand members actively shortlisting" },
            { n: "142", l: "Anonymous Client Records filed" },
          ].map((s, i) => (
            <div key={i} style={{ padding: "24px 28px", textAlign: "center", borderRight: i < 3 ? `1px solid ${DS.border}` : "none" }}>
              <div style={{ fontFamily: "Georgia,serif", fontSize: 40, color: DS.ink }}>{s.n}</div>
              <div style={{ fontSize: 9, color: DS.muted, marginTop: 4, letterSpacing: "0.1em", textTransform: "uppercase", lineHeight: 1.5 }}>{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* VERIFY CLAIMS */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, background: DS.parchmentDark, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56, alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 10 }}>FOR BRANDS & BUYERS</div>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 30, color: DS.ink, marginBottom: 14, lineHeight: 1.2 }}>Search any agency.<br />See what we actually found.</div>
            <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.8, marginBottom: 12 }}>An agency tells you they worked with Myntra. Search them on Few Found. See whether that claim is independently verified — or just a name on a pitch deck. Free to search. No account needed.</p>
            <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.8, marginBottom: 20 }}>Brand members see score bands, reference contacts, and the full evidence pack. Every element. The difference between verified and listed is visible to all. What it means is visible to members.</p>
            <div style={{ display: "flex", gap: 10 }}>
              <button style={{ background: DS.ink, color: DS.parchment, border: "none", padding: "10px 18px", fontSize: 11, cursor: "pointer", fontWeight: 700, letterSpacing: "0.06em" }}>SEARCH PROVIDERS</button>
              <button style={{ border: `1px solid ${DS.ink}`, background: "transparent", color: DS.ink, padding: "10px 18px", fontSize: 11, cursor: "pointer", letterSpacing: "0.06em" }}>BRAND MEMBERSHIP →</button>
            </div>
          </div>
          <div>
            <div style={{ fontSize: 9, letterSpacing: "0.1em", color: DS.muted, marginBottom: 10 }}>WHAT FEW FOUND ACTUALLY CHECKS</div>
            {[
              { c: "We worked with Nykaa", v: true, n: "Reference at Nykaa contacted directly. Confirmed by their Senior Marketing Manager." },
              { c: "We drove 400% ROAS for a D2C brand", v: false, n: "Claim not verified. No evidence submitted for this specific outcome." },
              { c: "Team of 40 specialists", v: true, n: "LinkedIn headcount cross-referenced. MCA filing consistent with claim." },
              { c: "Founded 2017", v: true, n: "MCA registration date: March 2017. Confirmed." },
              { c: "Won 3 industry awards", v: false, n: "Not independently verified. Listed claim only." },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", background: DS.parchment, border: `1px solid ${DS.border}`, marginBottom: 6 }}>
                <div style={{ width: 16, height: 16, background: item.v ? DS.ink : "transparent", border: `1px solid ${item.v ? DS.ink : DS.border}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <span style={{ color: item.v ? DS.parchment : DS.muted, fontSize: 9 }}>{item.v ? "✓" : "✗"}</span>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, color: DS.ink }}>{item.c}</div>
                  <div style={{ fontSize: 9, color: DS.muted, marginTop: 2 }}>{item.n}</div>
                </div>
                <span style={{ fontSize: 8, fontWeight: 700, letterSpacing: "0.1em", padding: "2px 7px", background: item.v ? DS.ink : "transparent", color: item.v ? DS.parchment : DS.muted, border: `1px solid ${item.v ? DS.ink : DS.border}`, flexShrink: 0 }}>
                  {item.v ? "VERIFIED" : "LISTED"}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED VERIFIED */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 20 }}>
            <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted }}>RECENTLY VERIFIED</div>
            <span style={{ fontSize: 11, color: DS.muted, cursor: "pointer" }}>Browse all verified →</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
            {providers.filter(p => p.verified).slice(0, 3).map((p, i) => (
              <ProviderCard key={i} name={p.name} cat={p.cat} city={p.city} verified={p.verified} yr={p.yr} size={p.size} services={p.services} bio={p.bio} />
            ))}
          </div>
        </div>
      </section>

      {/* CATEGORY GRID */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 28 }}>BROWSE ALL CATEGORIES</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 28 }}>
            {Object.entries(ALL_CATEGORIES).map(([key, cat]) => {
              const show = showAll[key];
              const visible = show ? cat.subs : cat.subs.slice(0, 7);
              return (
                <div key={key}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 12 }}>
                    <span style={{ fontSize: 16, color: DS.muted }}>{cat.icon}</span>
                    <div style={{ fontFamily: "Georgia,serif", fontSize: 14, color: DS.ink, cursor: "pointer" }}>{cat.label}</div>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                    {visible.map(sub => (
                      <div key={sub} style={{ fontSize: 11, color: DS.muted, cursor: "pointer", display: "flex", alignItems: "center", gap: 5 }}>
                        <span style={{ width: 4, height: 4, background: DS.border, borderRadius: "50%", flexShrink: 0 }} />
                        {sub}
                      </div>
                    ))}
                    {cat.subs.length > 7 && (
                      <div onClick={() => toggleAll(key)} style={{ fontSize: 10, color: DS.gold, cursor: "pointer", fontStyle: "italic", marginTop: 2 }}>
                        {show ? "Show less ↑" : `+${cat.subs.length - 7} more →`}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop: 40, paddingTop: 28, borderTop: `1px solid ${DS.border}` }}>
            <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 12 }}>BY CITY</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
              {CITIES.map(c => <button key={c} style={{ border: `1px solid ${DS.border}`, background: "transparent", color: DS.muted, padding: "5px 12px", fontSize: 11, cursor: "pointer" }}>{c}</button>)}
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 36 }}>HOW IT WORKS</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 40 }}>
            {[
              { n: "01", t: "List free. Today.", b: "Profile live in under 3 minutes. No approval. No waiting. Discoverable from the moment you submit — by brands and agencies searching right now." },
              { n: "02", t: "Apply for verification.", b: "Submit two references and one piece of evidence. The system contacts references automatically via secure form. You track progress in your dashboard." },
              { n: "03", t: "Get found ahead of everyone who did not bother.", b: "Verified providers appear first in every search. Always. Listed-only appear below. Brand members only contact verified providers directly." },
            ].map(s => (
              <div key={s.n}>
                <div style={{ fontFamily: "Georgia,serif", fontSize: 44, color: "rgba(6,6,8,0.1)", marginBottom: 14 }}>{s.n}</div>
                <div style={{ fontFamily: "Georgia,serif", fontSize: 17, color: DS.ink, marginBottom: 8 }}>{s.t}</div>
                <div style={{ fontSize: 12, color: DS.muted, lineHeight: 1.7 }}>{s.b}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CLIENT RECORD */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, background: DS.parchmentDark, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56, alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 10 }}>THE CLIENT RECORD — LIKE GLASSDOOR FOR MARKETING CLIENTS</div>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 28, color: DS.ink, marginBottom: 14, lineHeight: 1.25 }}>Agencies review brands.<br />Anonymously. Permanently.</div>
            <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.8, marginBottom: 14 }}>Every brand has a Client Record — filed anonymously by verified agencies, creators, and professionals who have worked with them. Payment behaviour. Brief quality. Approval turnaround. Scope management. Would they work with the brand again.</p>
            <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.8, marginBottom: 14 }}>Brands cannot delete Client Records. They can respond with verified factual data — like connecting their invoicing tool to show their actual payment history. The record is permanent and compounds over time.</p>
            <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.8 }}>This is the feature that changes behaviour in this ecosystem. A brand that knows their record is being built by the agencies they work with pays on time and briefs clearly.</p>
          </div>
          <div style={{ background: DS.parchment, border: `1px solid ${DS.border}`, padding: 24 }}>
            <div style={{ fontSize: 9, letterSpacing: "0.1em", color: DS.muted, marginBottom: 14 }}>SAMPLE CLIENT RECORD — BRAND X · FMCG</div>
            {[
              { m: "Payment within agreed terms", v: "4 of 5 engagements paid on time", good: true },
              { m: "Brief provided before work began", v: "Rated 4.2/5 by 5 verified agencies", good: true },
              { m: "Scope changes mid-campaign", v: "Noted in 2 of 5 Client Records", good: false },
              { m: "Approval turnaround", v: "Average 4.1 working days", good: true },
              { m: "Would work with again", v: "4 of 5 verified providers said yes", good: true },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: i < 4 ? `1px solid ${DS.border}` : "none", alignItems: "center", gap: 12 }}>
                <div style={{ fontSize: 11, color: DS.ink }}>{item.m}</div>
                <div style={{ fontSize: 10, color: item.good ? DS.ink : DS.muted, fontWeight: item.good ? 600 : 400, textAlign: "right", flexShrink: 0 }}>{item.v}</div>
              </div>
            ))}
            <div style={{ marginTop: 14, fontSize: 9, color: DS.muted, fontStyle: "italic" }}>Filed by 5 Few Found Verified providers · Anonymous · Updated 3 days ago</div>
          </div>
        </div>
      </section>

      {/* FOR EVERY STAKEHOLDER */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "56px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 28 }}>BUILT FOR EVERY STAKEHOLDER IN INDIA'S MARKETING ECOSYSTEM</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }}>
            {[
              { who: "Large Media Companies", what: "List your inventory. Get verified as a trusted publisher partner. Brand members see your Client Record from agencies who have placed with you.", cta: "List as publisher →" },
              { who: "Growing Agencies", what: "Verification levels the field against agencies with bigger brand names. Your verified track record speaks before you enter the room.", cta: "Get verified →" },
              { who: "Independent Creators", what: "Know which brands pay on time before you accept their brief. Verified audience authenticity ends the rate negotiation.", cta: "List as creator →" },
              { who: "Solo Professionals", what: "A verified fractional CMO with a track record wins mandates agencies cannot serve. Your independence is your advantage.", cta: "List as professional →" },
            ].map((s, i) => (
              <div key={i} style={{ border: `1px solid ${DS.border}`, padding: 20 }}>
                <div style={{ fontFamily: "Georgia,serif", fontSize: 14, color: DS.ink, marginBottom: 10 }}>{s.who}</div>
                <div style={{ fontSize: 11, color: DS.muted, lineHeight: 1.7, marginBottom: 14 }}>{s.what}</div>
                <div style={{ fontSize: 10, color: DS.muted, cursor: "pointer", letterSpacing: "0.06em" }}>{s.cta}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOMO CLOSER */}
      <section style={{ background: DS.ink, padding: "64px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", maxWidth: 580 }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: "rgba(244,241,232,0.3)", marginBottom: 14 }}>THE REALITY</div>
          <div style={{ fontFamily: "Georgia,serif", fontSize: 34, color: DS.parchment, lineHeight: 1.2, marginBottom: 18 }}>
            Every day you are not verified, a brand that searched for you found someone who was.
          </div>
          <div style={{ fontSize: 12, color: "rgba(244,241,232,0.5)", lineHeight: 1.8, marginBottom: 28 }}>
            Listing is free. Three minutes. Verified providers appear above listed-only providers in every search — permanently. The gap is visible to every brand member on the platform. It grows every day.
          </div>
          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <button style={{ background: DS.parchment, color: DS.ink, border: "none", padding: "12px 22px", fontSize: 11, cursor: "pointer", fontWeight: 700, letterSpacing: "0.08em" }}>LIST FREE NOW</button>
            <span style={{ fontSize: 11, color: "rgba(244,241,232,0.4)", cursor: "pointer" }}>Apply for verification →</span>
          </div>
        </div>
      </section>

      {/* THE RULE */}
      <section style={{ borderBottom: `1px solid ${DS.border}`, padding: "40px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", maxWidth: 680 }}>
          <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 14 }}>THE ONE RULE THAT NEVER BREAKS</div>
          <blockquote style={{ fontFamily: "Georgia,serif", fontSize: 19, color: DS.ink, lineHeight: 1.6, margin: "0 0 10px 0" }}>
            "Verified providers always appear above listed-only providers in every search result. No provider can pay to appear higher. No sponsored results. No featured placement. Ever."
          </blockquote>
          <div style={{ fontSize: 11, color: DS.muted }}>Hardcoded into the database query. Not a configuration setting. Cannot be changed from any admin panel.</div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ padding: "44px 32px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gridTemplateColumns: "180px repeat(4,1fr)", gap: 28 }}>
          <div><Wordmark size="sm" /><div style={{ fontSize: 10, color: DS.muted, marginTop: 10, lineHeight: 1.7 }}>India's trust layer for marketing service providers.</div></div>
          {[
            { t: "Browse", l: ["Agencies", "Creators", "Professionals", "Service Providers", "Brands"] },
            { t: "Cities", l: ["Mumbai", "Delhi NCR", "Bengaluru", "Hyderabad", "Chennai", "All cities →"] },
            { t: "Company", l: ["About", "How it works", "Verification Standards", "For Brands", "The Client Record", "Sitemap"] },
            { t: "Legal", l: ["Terms", "Privacy", "Reviewer Conduct", "Dispute Policy"] },
          ].map(col => (
            <div key={col.t}>
              <div style={{ fontSize: 9, letterSpacing: "0.12em", color: DS.muted, marginBottom: 12 }}>{col.t.toUpperCase()}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
                {col.l.map(l => <span key={l} style={{ fontSize: 11, color: DS.muted, cursor: "pointer" }}>{l}</span>)}
              </div>
            </div>
          ))}
        </div>
        <div style={{ maxWidth: 1100, margin: "20px auto 0", paddingTop: 20, borderTop: `1px solid ${DS.border}`, display: "flex", justifyContent: "space-between", fontSize: 10, color: DS.muted }}>
          <span>© 2026 Few Found. All rights reserved.</span>
          <span>Verified providers are independently assessed. Placement is never for sale.</span>
        </div>
      </footer>
    </div>
  );
}

// ── QUICK CAPTURE ─────────────────────────────────────────────
function QuickCapture({ onSuccess }) {
  const [step, setStep] = useState(1);
  const [type, setType] = useState(null);
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [authMethod, setAuthMethod] = useState(null);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const types = Object.entries(ALL_CATEGORIES).map(([k, v]) => ({ key: k, icon: v.icon, label: v.label }));

  function handleSubmit() {
    setLoading(true);
    setTimeout(() => { setLoading(false); onSuccess({ name, type, city, authMethod }); }, 1500);
  }

  return (
    <div style={{ background: DS.parchment, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 32 }}>
      <div style={{ width: "100%", maxWidth: 520 }}>
        <div style={{ marginBottom: 32, textAlign: "center" }}><Wordmark size="md" /></div>

        {/* Step indicator */}
        <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: 32 }}>
          {["Choose type", "Sign in", "Your name & city", "Live"].map((s, i) => (
            <>
              <div key={s} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, flex: 1 }}>
                <div style={{ width: 24, height: 24, borderRadius: "50%", background: i + 1 <= step ? DS.ink : DS.border, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: 10, color: i + 1 <= step ? DS.parchment : DS.muted, fontWeight: 700 }}>{i + 1}</span>
                </div>
                <span style={{ fontSize: 9, color: i + 1 === step ? DS.ink : DS.muted, letterSpacing: "0.06em", textAlign: "center", whiteSpace: "nowrap" }}>{s.toUpperCase()}</span>
              </div>
              {i < 3 && <div key={`line-${i}`} style={{ height: 1, flex: 0.5, background: i + 1 < step ? DS.ink : DS.border, marginBottom: 14 }} />}
            </>
          ))}
        </div>

        {/* Step 1: Type */}
        {step === 1 && (
          <div>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 26, color: DS.ink, marginBottom: 6 }}>What are you listing?</div>
            <div style={{ fontSize: 12, color: DS.muted, marginBottom: 24 }}>Choose your type. Listing is free and takes under 3 minutes.</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {types.map(t => (
                <button key={t.key} onClick={() => { setType(t.key); setStep(2); }}
                  style={{ border: `1px solid ${type === t.key ? DS.ink : DS.border}`, background: type === t.key ? DS.ink : "transparent", color: type === t.key ? DS.parchment : DS.ink, padding: "16px 14px", cursor: "pointer", textAlign: "left", transition: "all 0.15s" }}>
                  <div style={{ fontSize: 18, marginBottom: 8 }}>{t.icon}</div>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4, letterSpacing: "0.04em" }}>
                    {t.label === "Service Providers" ? "Service Provider" : t.label.replace(/s$/, "")}
                  </div>
                  <div style={{ fontSize: 10, opacity: 0.6, lineHeight: 1.5 }}>
                    {t.key === "agencies" && "Agencies, studios, and marketing companies"}
                    {t.key === "creators" && "Instagram, YouTube, LinkedIn, podcast"}
                    {t.key === "professionals" && "Fractional, freelance, independent"}
                    {t.key === "serviceProviders" && "Vendors, suppliers, publishers"}
                    {t.key === "brands" && "Brands seeking to build their client record"}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Auth */}
        {step === 2 && (
          <div>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 26, color: DS.ink, marginBottom: 6 }}>Create your account</div>
            <div style={{ fontSize: 12, color: DS.muted, marginBottom: 24 }}>Listing as a <strong>{ALL_CATEGORIES[type]?.label.replace(/s$/, "")}</strong>. Your account ties to your profile permanently.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 20 }}>
              {[
                { id: "google", label: "Continue with Google", icon: "G" },
                { id: "linkedin", label: "Continue with LinkedIn", icon: "in" },
              ].map(opt => (
                <button key={opt.id} onClick={() => { setAuthMethod(opt.id); setStep(3); }}
                  style={{ border: `1px solid ${DS.border}`, background: DS.parchment, color: DS.ink, padding: "13px 18px", cursor: "pointer", display: "flex", alignItems: "center", gap: 12, fontSize: 13, transition: "border-color 0.15s" }}>
                  <span style={{ width: 24, height: 24, background: DS.ink, color: DS.parchment, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700 }}>{opt.icon}</span>
                  {opt.label}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <div style={{ flex: 1, height: 1, background: DS.border }} />
              <span style={{ fontSize: 11, color: DS.muted }}>or use email</span>
              <div style={{ flex: 1, height: 1, background: DS.border }} />
            </div>
            <input type="email" placeholder="your@work-email.com" value={email} onChange={e => setEmail(e.target.value)}
              style={{ width: "100%", border: `1px solid ${DS.border}`, padding: "12px 14px", fontSize: 13, color: DS.ink, background: DS.parchment, outline: "none", marginBottom: 10, boxSizing: "border-box" }} />
            <button onClick={() => { if (email) { setAuthMethod("email"); setStep(3); } }}
              style={{ width: "100%", background: email ? DS.ink : DS.border, color: DS.parchment, border: "none", padding: "12px", fontSize: 12, cursor: email ? "pointer" : "not-allowed", fontWeight: 700, letterSpacing: "0.08em" }}>
              SEND MAGIC LINK
            </button>
            <div style={{ fontSize: 10, color: DS.muted, textAlign: "center", marginTop: 10 }}>
              A magic link will be sent to your email. One click and you're in. No password needed.
            </div>
          </div>
        )}

        {/* Step 3: Quick details */}
        {step === 3 && (
          <div>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 26, color: DS.ink, marginBottom: 6 }}>Almost there</div>
            <div style={{ fontSize: 12, color: DS.muted, marginBottom: 24 }}>Two quick details and your profile goes live.</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 11, color: DS.muted, display: "block", marginBottom: 5, letterSpacing: "0.06em" }}>
                  {type === "agencies" && "AGENCY NAME"}
                  {type === "creators" && "YOUR NAME OR CREATOR NAME"}
                  {type === "professionals" && "YOUR FULL NAME"}
                  {type === "serviceProviders" && "COMPANY OR STUDIO NAME"}
                  {type === "brands" && "BRAND NAME"}
                </label>
                <input value={name} onChange={e => setName(e.target.value)} placeholder="Enter your name..."
                  style={{ width: "100%", border: `1px solid ${DS.border}`, padding: "12px 14px", fontSize: 13, color: DS.ink, background: DS.parchment, outline: "none", boxSizing: "border-box" }} />
              </div>
              <div>
                <label style={{ fontSize: 11, color: DS.muted, display: "block", marginBottom: 5, letterSpacing: "0.06em" }}>PRIMARY CITY</label>
                <select value={city} onChange={e => setCity(e.target.value)}
                  style={{ width: "100%", border: `1px solid ${DS.border}`, padding: "12px 14px", fontSize: 13, color: DS.ink, background: DS.parchment, outline: "none", boxSizing: "border-box" }}>
                  <option value="">Select your city</option>
                  {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <button onClick={handleSubmit} disabled={!name || !city || loading}
              style={{ width: "100%", marginTop: 20, background: name && city && !loading ? DS.ink : DS.border, color: DS.parchment, border: "none", padding: "13px", fontSize: 12, cursor: name && city ? "pointer" : "not-allowed", fontWeight: 700, letterSpacing: "0.08em" }}>
              {loading ? "CREATING YOUR PROFILE..." : "LIST FREE — GO LIVE NOW"}
            </button>
            <div style={{ fontSize: 10, color: DS.muted, textAlign: "center", marginTop: 10, lineHeight: 1.6 }}>
              Your profile goes live immediately. No approval. No waiting. You can complete your profile details in your dashboard.
            </div>
          </div>
        )}

        <button onClick={() => step > 1 && setStep(s => s - 1)} style={{ display: step > 1 ? "block" : "none", background: "none", border: "none", color: DS.muted, fontSize: 12, cursor: "pointer", marginTop: 20, padding: 0 }}>← Back</button>
      </div>
    </div>
  );
}

// ── DASHBOARD ──────────────────────────────────────────────────
function Dashboard({ providerData }) {
  const { name = "Meridian Performance", type = "agencies", city = "Mumbai" } = providerData || {};
  const [completedSections, setCompleted] = useState([]);
  const toggle = (s) => setCompleted(p => p.includes(s) ? p.filter(x => x !== s) : [...p, s]);

  const sections = [
    { id: "services", label: "Services", desc: "Which services do you offer?", impact: "Appear in filtered searches by brands looking for your specific services.", icon: "◆" },
    { id: "clients", label: "Notable clients", desc: "2 brand names you have worked with", impact: "Agencies with named clients get 3x more profile visits from brand members.", icon: "◉" },
    { id: "bio", label: "About you", desc: "150-word description", impact: "Your bio is what AI search tools surface when brands ask for recommendations.", icon: "◈" },
    { id: "website", label: "Website", desc: "Your agency or personal website", impact: "Required for verification. Brands check it before contacting.", icon: "◇" },
    { id: "details", label: "Details", desc: "Founding year, team size", impact: "Brands filter by team size. Agencies with complete details appear in more results.", icon: "◫" },
  ];

  const completion = Math.round((completedSections.length / sections.length) * 100 + 20);
  const clampedCompletion = Math.min(completion, 100);

  return (
    <div style={{ background: DS.parchment, minHeight: "100vh" }}>
      {/* Dashboard nav */}
      <nav style={{ background: DS.parchment, borderBottom: `1px solid ${DS.border}`, padding: "12px 32px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Wordmark size="sm" />
        <div style={{ display: "flex", gap: 20, fontSize: 12, color: DS.muted }}>
          <span style={{ color: DS.ink, fontWeight: 600 }}>My Profile</span>
          <span>Verification</span>
          <span>Client Records</span>
          <span>Settings</span>
        </div>
        <div style={{ fontSize: 12, color: DS.muted }}>Signed in as {name}</div>
      </nav>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "40px 32px", display: "grid", gridTemplateColumns: "1fr 320px", gap: 40 }}>
        {/* Main */}
        <div>
          {/* Status bar */}
          <div style={{ background: DS.parchmentDark, border: `1px solid ${DS.border}`, padding: "20px 24px", marginBottom: 28 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div style={{ fontFamily: "Georgia,serif", fontSize: 18, color: DS.ink }}>Profile completeness</div>
              <div style={{ fontSize: 22, fontFamily: "Georgia,serif", color: DS.ink, fontWeight: 700 }}>{clampedCompletion}%</div>
            </div>
            <div style={{ height: 4, background: DS.border, borderRadius: 2, marginBottom: 12 }}>
              <div style={{ height: "100%", background: clampedCompletion >= 80 ? DS.ink : DS.gold, width: `${clampedCompletion}%`, transition: "width 0.4s", borderRadius: 2 }} />
            </div>
            {clampedCompletion >= 80
              ? <div style={{ fontSize: 11, color: DS.ink, fontWeight: 600 }}>✓ Your profile is strong enough to apply for verification. Apply when you are ready.</div>
              : <div style={{ fontSize: 11, color: DS.muted }}>Complete your profile to improve visibility and unlock verification eligibility.</div>}
          </div>

          {/* Profile sections */}
          <div style={{ fontFamily: "Georgia,serif", fontSize: 20, color: DS.ink, marginBottom: 16 }}>Complete your profile</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {sections.map(section => {
              const done = completedSections.includes(section.id);
              return (
                <div key={section.id} style={{ border: `1px solid ${done ? DS.ink : DS.border}`, padding: "16px 20px", background: done ? DS.ink : DS.parchment, cursor: "pointer", transition: "all 0.15s" }}
                  onClick={() => toggle(section.id)}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <span style={{ fontSize: 16, color: done ? DS.parchment : DS.muted }}>{section.icon}</span>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600, color: done ? DS.parchment : DS.ink, marginBottom: 2 }}>{section.label}</div>
                        <div style={{ fontSize: 11, color: done ? "rgba(244,241,232,0.6)" : DS.muted }}>{section.desc}</div>
                      </div>
                    </div>
                    <span style={{ fontSize: 12, color: done ? DS.gold : DS.muted, fontWeight: done ? 700 : 400 }}>{done ? "✓ Done" : "Add →"}</span>
                  </div>
                  {!done && (
                    <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${DS.border}`, fontSize: 10, color: DS.gold, fontStyle: "italic" }}>
                      {section.impact}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Verification CTA */}
          {clampedCompletion >= 80 && (
            <div style={{ border: `2px solid ${DS.ink}`, padding: "24px", marginTop: 24 }}>
              <div style={{ fontFamily: "Georgia,serif", fontSize: 18, color: DS.ink, marginBottom: 8 }}>Ready to apply for verification</div>
              <p style={{ fontSize: 12, color: DS.muted, lineHeight: 1.7, marginBottom: 16 }}>Your profile is complete. Verification puts you above listed-only providers in every search. Submit two references and one piece of evidence. The system handles the rest.</p>
              <button style={{ background: DS.ink, color: DS.parchment, border: "none", padding: "11px 20px", fontSize: 11, cursor: "pointer", fontWeight: 700, letterSpacing: "0.08em" }}>
                APPLY FOR VERIFICATION →
              </button>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Profile preview */}
          <div style={{ border: `1px solid ${DS.border}`, padding: 20 }}>
            <div style={{ fontSize: 9, letterSpacing: "0.1em", color: DS.muted, marginBottom: 14 }}>YOUR LISTING</div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <div>
                <div style={{ fontFamily: "Georgia,serif", fontSize: 15, color: DS.ink }}>{name}</div>
                <div style={{ fontSize: 10, color: DS.muted, marginTop: 2 }}>{ALL_CATEGORIES[type]?.label.replace(/s$/, "")} · {city}</div>
              </div>
              <Badge verified={false} />
            </div>
            <div style={{ fontSize: 10, color: DS.muted, marginBottom: 12 }}>Your listing is live and discoverable. Complete your profile to improve visibility.</div>
            <button style={{ width: "100%", border: `1px solid ${DS.border}`, background: "transparent", color: DS.ink, padding: "8px", fontSize: 10, cursor: "pointer", letterSpacing: "0.06em" }}>VIEW PUBLIC PROFILE →</button>
          </div>

          {/* Stats */}
          <div style={{ border: `1px solid ${DS.border}`, padding: 20 }}>
            <div style={{ fontSize: 9, letterSpacing: "0.1em", color: DS.muted, marginBottom: 14 }}>PROFILE ACTIVITY</div>
            {[
              { l: "Profile views this week", v: "0" },
              { l: "Search appearances", v: "0" },
              { l: "Brand member views", v: "0" },
            ].map(s => (
              <div key={s.l} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${DS.border}` }}>
                <span style={{ fontSize: 11, color: DS.muted }}>{s.l}</span>
                <span style={{ fontSize: 13, color: DS.ink, fontFamily: "Georgia,serif" }}>{s.v}</span>
              </div>
            ))}
            <div style={{ fontSize: 10, color: DS.muted, marginTop: 10, fontStyle: "italic" }}>Activity increases when your profile is complete and verified.</div>
          </div>

          {/* FOMO */}
          <div style={{ background: DS.ink, color: DS.parchment, padding: 20 }}>
            <div style={{ fontSize: 10, letterSpacing: "0.1em", color: "rgba(244,241,232,0.4)", marginBottom: 10 }}>HAPPENING NOW</div>
            <div style={{ fontSize: 12, color: DS.parchment, lineHeight: 1.7, marginBottom: 10 }}>3 brand members searched for {ALL_CATEGORIES[type]?.label} in {city} this week.</div>
            <div style={{ fontSize: 10, color: DS.gold, fontStyle: "italic" }}>Verified providers appeared in those searches. Listed-only did not.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── MAIN WIREFRAME APP ─────────────────────────────────────────
export default function App() {
  const [currentPage, setCurrentPage] = useState("homepage");
  const [approved, setApproved] = useState([]);
  const [showBackend, setShowBackend] = useState(false);
  const [showQA, setShowQA] = useState(true);
  const [qaAnswers, setQaAnswers] = useState({});
  const [listingData, setListingData] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const currentQA = QA[currentPage] || [];
  const allAnswered = currentQA.every((_, i) => qaAnswers[`${currentPage}-${i}`]);
  const canApprove = currentQA.length === 0 || allAnswered;

  function approve() {
    if (!approved.includes(currentPage)) setApproved(p => [...p, currentPage]);
    const keys = Object.keys(PAGES);
    const next = keys[keys.indexOf(currentPage) + 1];
    if (next) setCurrentPage(next);
  }

  const renderPage = () => {
    switch (currentPage) {
      case "homepage": return <Homepage />;
      case "listing-quick": return <QuickCapture onSuccess={(data) => { setListingData(data); approve(); }} />;
      case "listing-dashboard": return <Dashboard providerData={listingData} />;
      case "empty-category": return (
        <div style={{ background: DS.parchment, minHeight: "100vh", padding: 40 }}>
          <div style={{ maxWidth: 700, margin: "0 auto" }}>
            <div style={{ fontSize: 9, letterSpacing: "0.1em", color: DS.muted, marginBottom: 20 }}>PERFORMANCE MARKETING AGENCIES · JAIPUR</div>
            <EmptyState category="Performance Marketing" city="Jaipur" />
          </div>
        </div>
      );
      default: return (
        <div style={{ background: DS.parchment, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ textAlign: "center", maxWidth: 400 }}>
            <div style={{ fontFamily: "Georgia,serif", fontSize: 28, color: DS.ink, marginBottom: 12 }}>{PAGES[currentPage]}</div>
            <div style={{ fontSize: 13, color: DS.muted, marginBottom: 24, lineHeight: 1.7 }}>Approve the previous pages to unlock this page in sequence.</div>
            <div style={{ border: `1px solid ${DS.border}`, padding: 20 }}>
              <div style={{ fontSize: 11, color: DS.muted }}>Waiting for approval of previous pages in sequence.</div>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "Arial, sans-serif", overflow: "hidden" }}>

      {/* SIDEBAR */}
      <div style={{ width: sidebarOpen ? 240 : 42, background: "#0d0d0f", borderRight: "1px solid #1e1e22", display: "flex", flexDirection: "column", transition: "width 0.2s", overflow: "hidden", flexShrink: 0 }}>
        <div style={{ padding: "14px 12px", borderBottom: "1px solid #1e1e22", display: "flex", justifyContent: sidebarOpen ? "space-between" : "center", alignItems: "center" }}>
          {sidebarOpen && <span style={{ fontSize: 9, color: "#444", letterSpacing: "0.12em" }}>FEW FOUND · WIREFRAME</span>}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 13, padding: 0 }}>{sidebarOpen ? "←" : "→"}</button>
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {Object.entries(PAGES).map(([key, label]) => {
            const isApproved = approved.includes(key);
            const isCurrent = currentPage === key;
            return (
              <div key={key} onClick={() => setCurrentPage(key)}
                style={{ padding: sidebarOpen ? "9px 14px" : "9px 8px", cursor: "pointer", background: isCurrent ? "#1a1a1e" : "transparent", borderLeft: `2px solid ${isCurrent ? DS.gold : "transparent"}`, display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: isApproved ? "#4CAF50" : isCurrent ? DS.gold : "#444", flexShrink: 0 }}>
                  {isApproved ? "✓" : isCurrent ? "●" : "○"}
                </span>
                {sidebarOpen && <span style={{ fontSize: 10, color: isCurrent ? "#e0ddd6" : "#555", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{label}</span>}
              </div>
            );
          })}
        </div>
        {sidebarOpen && (
          <div style={{ padding: 14, borderTop: "1px solid #1e1e22" }}>
            <div style={{ fontSize: 9, color: "#444", marginBottom: 6, letterSpacing: "0.1em" }}>
              {approved.length}/{Object.keys(PAGES).length} APPROVED
            </div>
            <div style={{ height: 2, background: "#1e1e22" }}>
              <div style={{ height: "100%", background: DS.gold, width: `${(approved.length / Object.keys(PAGES).length) * 100}%`, transition: "width 0.3s" }} />
            </div>
          </div>
        )}
      </div>

      {/* MAIN */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

        {/* Toolbar */}
        <div style={{ background: "#111113", borderBottom: "1px solid #1e1e22", padding: "9px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
          <div style={{ fontSize: 11, color: "#666" }}>
            <span style={{ color: DS.gold }}>{PAGES[currentPage]}</span>
            {approved.includes(currentPage) && <span style={{ color: "#4CAF50", marginLeft: 12 }}>✓ Approved</span>}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => setShowBackend(!showBackend)} style={{ background: showBackend ? "#1e1e22" : "transparent", border: "1px solid #2a2a2e", color: showBackend ? DS.gold : "#555", padding: "4px 10px", fontSize: 10, cursor: "pointer", letterSpacing: "0.06em" }}>
              {showBackend ? "⬡ BACKEND" : "⬡ BACKEND"}
            </button>
            <button onClick={() => setShowQA(!showQA)} style={{ background: showQA ? "#1e1e22" : "transparent", border: "1px solid #2a2a2e", color: showQA ? DS.gold : "#555", padding: "4px 10px", fontSize: 10, cursor: "pointer", letterSpacing: "0.06em" }}>
              {showQA ? "◈ QA" : "◈ QA"}
            </button>
          </div>
        </div>

        {/* Content */}
        <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
          <div style={{ flex: 1, overflow: "auto" }}>{renderPage()}</div>

          {/* Right panel */}
          {(showBackend || showQA) && (
            <div style={{ width: 340, borderLeft: "1px solid #1e1e22", display: "flex", flexDirection: "column", overflow: "hidden", flexShrink: 0 }}>

              {/* Backend */}
              {showBackend && BACKEND[currentPage] && (
                <div style={{ flex: showQA ? "none" : 1, overflow: "auto", maxHeight: showQA ? "50%" : "100%", background: "#0a0a0c", padding: 16, borderBottom: showQA ? "1px solid #1e1e22" : "none" }}>
                  <div style={{ fontSize: 9, color: DS.gold, letterSpacing: "0.12em", marginBottom: 12 }}>⬡ BACKEND — WHAT HAPPENS INVISIBLY</div>
                  {BACKEND[currentPage].map((step, i) => (
                    <div key={i} style={{ marginBottom: 12, paddingLeft: 10, borderLeft: "1px solid #222" }}>
                      <div style={{ fontSize: 9, color: DS.gold, marginBottom: 3, letterSpacing: "0.06em" }}>{step.role.toUpperCase()}</div>
                      <div style={{ fontSize: 10, color: "#888", lineHeight: 1.6 }}>{step.action}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* QA */}
              {showQA && (
                <div style={{ flex: 1, overflow: "auto", background: DS.parchmentDark, padding: 16 }}>
                  <div style={{ fontFamily: "Georgia,serif", fontSize: 15, color: DS.ink, marginBottom: 14 }}>QA Review</div>

                  {currentQA.length === 0 ? (
                    <div style={{ fontSize: 11, color: DS.muted, marginBottom: 14 }}>No open questions for this page.</div>
                  ) : (
                    currentQA.map((item, i) => {
                      const key = `${currentPage}-${i}`;
                      return (
                        <div key={i} style={{ marginBottom: 16, paddingBottom: 16, borderBottom: `1px solid ${DS.border}` }}>
                          <div style={{ fontSize: 9, color: DS.gold, letterSpacing: "0.1em", marginBottom: 6 }}>● QUESTION {i + 1}</div>
                          <div style={{ fontSize: 11, color: DS.ink, lineHeight: 1.6, marginBottom: 10 }}>{item.q}</div>
                          <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                            {item.opts.map(opt => (
                              <button key={opt} onClick={() => setQaAnswers(a => ({ ...a, [key]: opt }))}
                                style={{ padding: "6px 10px", fontSize: 10, cursor: "pointer", textAlign: "left", background: qaAnswers[key] === opt ? DS.ink : "transparent", color: qaAnswers[key] === opt ? DS.parchment : DS.ink, border: `1px solid ${qaAnswers[key] === opt ? DS.ink : DS.border}`, letterSpacing: "0.04em" }}>
                                {qaAnswers[key] === opt ? "✓ " : ""}{opt}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })
                  )}

                  <button onClick={approve} disabled={!canApprove}
                    style={{ width: "100%", padding: "11px", background: canApprove ? DS.ink : DS.border, color: DS.parchment, border: "none", cursor: canApprove ? "pointer" : "not-allowed", fontSize: 10, fontWeight: 700, letterSpacing: "0.1em" }}>
                    {canApprove
                      ? `✓ APPROVE — PROCEED TO ${Object.keys(PAGES)[Object.keys(PAGES).indexOf(currentPage) + 1] ? PAGES[Object.keys(PAGES)[Object.keys(PAGES).indexOf(currentPage) + 1]].split(" — ")[1]?.toUpperCase() || "NEXT" : "COMPLETE"}`
                      : `ANSWER ${currentQA.length - Object.keys(qaAnswers).filter(k => k.startsWith(currentPage)).length} QUESTIONS TO PROCEED`
                    }
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
