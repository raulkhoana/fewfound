import React, { useState, useEffect, useRef } from "react";

const T = {
  bg:"#F8F6F0", bgWarm:"#F2EFE8", bgWhite:"#FFFFFF",
  ink:"#0A0908", inkMid:"#3D3B38", inkLight:"#7A7773",
  gold:"#C4900A", border:"#E2DED6", borderMd:"#C8C4BC", dark:"#0A0908",
  sans:"'Helvetica Neue', Arial, sans-serif",
  serif:"Georgia, 'Times New Roman', serif",
  mono:"'Courier New', monospace",
};

// ── WORDMARK — flex with individual letter spans ───────────────────────────
function Wordmark({ size="sm", dark=false }) {
  const color = dark ? T.bg : T.ink;
  const cfg = {
    sm:   { fs:11, fw1:700, fw2:900, gap:6,  rh:1   },
    md:   { fs:18, fw1:700, fw2:900, gap:9,  rh:1.5 },
    lg:   { fs:32, fw1:700, fw2:900, gap:14, rh:2   },
    hero: { fs:76, fw1:700, fw2:900, gap:32, rh:3   },
  };
  const c = cfg[size]||cfg.sm;
  const ls = fw => ({ fontFamily:T.serif, fontSize:c.fs, fontWeight:fw, color, lineHeight:1, display:"inline-block" });
  return (
    <div style={{ display:"inline-flex", flexDirection:"column" }}>
      <div style={{ display:"flex", gap:c.gap }}>
        {"FEW".split("").map((l,i) => <span key={i} style={ls(c.fw1)}>{l}</span>)}
      </div>
      <div style={{ height:c.rh, background:T.gold, margin:`${Math.round(c.gap*0.6)}px 0`, width:"100%" }} />
      <div style={{ display:"flex", gap:Math.round(c.gap*0.55) }}>
        {"FOUND".split("").map((l,i) => <span key={i} style={ls(c.fw2)}>{l}</span>)}
      </div>
    </div>
  );
}

function Badge({ verified }) {
  return verified ? (
    <span style={{ display:"inline-flex", alignItems:"center", gap:4, background:T.ink, color:T.bg, fontSize:9, fontWeight:700, letterSpacing:"0.1em", padding:"3px 8px", fontFamily:T.sans }}>
      ✦ FEW FOUND VERIFIED
    </span>
  ) : (
    <span style={{ display:"inline-flex", border:`1px solid ${T.border}`, color:T.inkLight, fontSize:9, fontWeight:600, letterSpacing:"0.1em", padding:"3px 8px", fontFamily:T.sans }}>
      LISTED
    </span>
  );
}

const PARTNERS = [
  { label:"Performance Agency",       city:"Mumbai"    },
  { label:"Creative & Brand Agency",  city:"Mumbai"    },
  { label:"Media Planning Agency",    city:"Delhi"     },
  { label:"App Marketing Agency",     city:"Bengaluru" },
  { label:"PR & Communications",      city:"Delhi"     },
  { label:"Social Media Agency",      city:"Bengaluru" },
  { label:"Affiliate Agency",         city:"Hyderabad" },
  { label:"Martech Consultancy",      city:"Hyderabad" },
  { label:"Influencer Agency",        city:"Mumbai"    },
  { label:"Analytics Consultancy",    city:"Delhi"     },
  { label:"D2C Growth Agency",        city:"Bengaluru" },
  { label:"Content Marketing Agency", city:"Chennai"   },
];

const BRANDS = [
  { label:"Leading D2C Beauty Brand",   city:"Mumbai"    },
  { label:"Top Fintech Startup",         city:"Bengaluru" },
  { label:"Premium FMCG Company",        city:"Delhi"     },
  { label:"Consumer Tech Brand",         city:"Bengaluru" },
  { label:"D2C Food & Beverage Brand",   city:"Mumbai"    },
  { label:"Series B EdTech Company",     city:"Delhi"     },
  { label:"Healthcare Brand",            city:"Hyderabad" },
  { label:"Fashion & Apparel Brand",     city:"Mumbai"    },
  { label:"Quick Commerce Player",       city:"Bengaluru" },
  { label:"Financial Services Company",  city:"Mumbai"    },
];

function PartnerCard({ label, city }) {
  const [h,setH] = useState(false);
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
      style={{ width:220, flexShrink:0, border:`1px solid ${h?T.borderMd:T.border}`, padding:"16px 18px", background:T.bgWhite, cursor:"pointer", transition:"all 0.2s", transform:h?"translateY(-2px)":"translateY(0)" }}>
      <div style={{ marginBottom:10 }}><Badge verified /></div>
      <p style={{ fontFamily:T.serif, fontSize:14, color:T.ink, margin:"0 0 3px", lineHeight:1.3 }}>{label}</p>
      <p style={{ fontFamily:T.sans, fontSize:11, color:T.inkLight, margin:"0 0 8px" }}>{city}</p>
      <p style={{ fontFamily:T.sans, fontSize:9, color:T.inkLight, margin:0, fontStyle:"italic" }}>Sample profile · Real names listed soon</p>
    </div>
  );
}

function BrandCard({ label, city }) {
  const [h,setH] = useState(false);
  return (
    <div onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
      style={{ width:200, flexShrink:0, border:`1px solid ${h?T.borderMd:T.border}`, padding:"14px 16px", background:T.bgWhite, cursor:"pointer", transition:"all 0.2s" }}>
      <div style={{ width:30, height:30, background:T.bgWarm, border:`1px solid ${T.border}`, borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center", marginBottom:10 }}>
        <span style={{ fontFamily:T.serif, fontSize:12, color:T.inkMid, fontWeight:700 }}>{label.charAt(0)}</span>
      </div>
      <p style={{ fontFamily:T.sans, fontSize:12, color:T.ink, margin:"0 0 3px", fontWeight:600, lineHeight:1.3 }}>{label}</p>
      <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, margin:"0 0 8px" }}>{city}</p>
      <p style={{ fontFamily:T.sans, fontSize:9, color:T.inkLight, margin:0, fontStyle:"italic" }}>Placeholder · Actual brands listed soon</p>
    </div>
  );
}

function AutoScroller({ items, CardComponent, speed=0.5 }) {
  const ref = useRef(null);
  const doubled = [...items,...items];
  useEffect(()=>{
    const el = ref.current; if(!el) return;
    let frame, x=0;
    const half = el.scrollWidth/2;
    function tick(){ x+=speed; if(x>=half) x=0; el.style.transform=`translateX(-${x}px)`; frame=requestAnimationFrame(tick); }
    frame=requestAnimationFrame(tick);
    return ()=>cancelAnimationFrame(frame);
  },[]);
  return (
    <div style={{ overflow:"hidden", width:"100%" }}>
      <div ref={ref} style={{ display:"flex", gap:12, width:"max-content", willChange:"transform" }}>
        {doubled.map((item,i)=><CardComponent key={i} {...item}/>)}
      </div>
    </div>
  );
}

function WhatsAppButton() {
  const [hov,setHov] = useState(false);
  return (
    <a href="https://wa.me/919999999999?text=Hi%20Few%20Found%2C%20I%20have%20a%20question"
      target="_blank" rel="noopener noreferrer"
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{ position:"fixed", bottom:80, left:24, zIndex:900, display:"flex", alignItems:"center", gap:8, textDecoration:"none", background:"#25D366", borderRadius:50, padding:hov?"10px 16px":"11px", boxShadow:"0 4px 16px rgba(37,211,102,0.3)", transition:"all 0.25s" }}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
      {hov && <span style={{ fontFamily:T.sans, fontSize:12, color:"white", fontWeight:600, whiteSpace:"nowrap" }}>Chat with us</span>}
    </a>
  );
}

function Nav() {
  return (
    <nav style={{ background:T.bg, borderBottom:`1px solid ${T.border}`, padding:"13px 48px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:200 }}>
      <Wordmark size="sm"/>
      <div style={{ display:"flex", gap:24, alignItems:"center" }}>
        {["Agencies","Creators","Professionals","Brands"].map(l=>(
          <span key={l} style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, cursor:"pointer" }}>{l}</span>
        ))}
        <span style={{ fontFamily:T.sans, fontSize:13, color:T.ink, cursor:"pointer", fontWeight:700, borderBottom:`1.5px solid ${T.ink}`, paddingBottom:1 }}>Review a brand</span>
        <span style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, cursor:"pointer" }}>How it works</span>
      </div>
      <div style={{ display:"flex", gap:10 }}>
        <button style={{ background:"transparent", border:`1px solid ${T.ink}`, color:T.ink, padding:"7px 16px", fontSize:12, cursor:"pointer", fontFamily:T.sans }}>For brands</button>
        <button style={{ background:T.ink, border:"none", color:T.bg, padding:"7px 16px", fontSize:12, cursor:"pointer", fontFamily:T.sans, fontWeight:600 }}>List free →</button>
      </div>
    </nav>
  );
}

function Hero() {
  const [hov,setHov] = useState(null);
  const types = [
    { id:"agency",       label:"List as agency",       note:"Verified agencies getting brand enquiries now" },
    { id:"creator",      label:"List as creator",       note:"Verified creators in brand shortlists now"    },
    { id:"professional", label:"List as professional",  note:"Most searched category by brands right now"   },
    { id:"brand",        label:"List as brand",         note:"Signal you are a serious marketing client"    },
  ];
  return (
    <section style={{ background:T.dark, padding:"72px 48px 64px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ marginBottom:28 }}><Wordmark size="hero" dark/></div>
        <p style={{ fontFamily:T.serif, fontSize:22, color:"rgba(248,246,240,0.72)", maxWidth:500, lineHeight:1.5, marginBottom:10 }}>
          India's trust layer for marketing service providers.
        </p>
        <p style={{ fontFamily:T.sans, fontSize:14, color:"rgba(248,246,240,0.35)", maxWidth:420, lineHeight:1.7, marginBottom:44 }}>
          The best brands are already here — searching for verified agencies, creators, and professionals. Are you listed?
        </p>
        <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
          {types.map(t=>(
            <div key={t.id} onMouseEnter={()=>setHov(t.id)} onMouseLeave={()=>setHov(null)}
              style={{ border:`1px solid ${hov===t.id?"rgba(248,246,240,0.42)":"rgba(248,246,240,0.1)"}`, padding:"14px 20px", cursor:"pointer", transition:"border-color 0.2s", minWidth:188 }}>
              <p style={{ fontFamily:T.sans, fontSize:13, color:T.bg, fontWeight:600, margin:"0 0 6px" }}>{t.label} →</p>
              <p style={{ fontFamily:T.sans, fontSize:11, color:T.gold, margin:0, fontStyle:"italic" }}>{t.note}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BrandsSection() {
  return (
    <section style={{ background:T.bgWarm, borderBottom:`1px solid ${T.border}`, padding:"36px 0" }}>
      <div style={{ padding:"0 48px", marginBottom:18 }}>
        <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", margin:0 }}>Brands who trust Few Found</p>
      </div>
      <AutoScroller items={BRANDS} CardComponent={BrandCard} speed={0.4}/>
    </section>
  );
}

function PartnersSection() {
  return (
    <section style={{ background:T.bg, borderBottom:`1px solid ${T.border}`, padding:"36px 0" }}>
      <div style={{ padding:"0 48px", marginBottom:18, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", margin:0 }}>Few Found Verified partners</p>
        <span style={{ fontFamily:T.sans, fontSize:12, color:T.ink, textDecoration:"underline", cursor:"pointer" }}>Browse all verified →</span>
      </div>
      <AutoScroller items={PARTNERS} CardComponent={PartnerCard} speed={0.5}/>
    </section>
  );
}

function SearchSection() {
  const [q,setQ] = useState("");
  const claims = [
    { text:"Worked with a leading beauty brand",   ok:true,  note:"Reference contacted independently. Confirmed."  },
    { text:"Drove 400% ROAS for a D2C client",      ok:false, note:"Not verified. Evidence not submitted."          },
    { text:"Team of 40 specialists in-house",       ok:true,  note:"LinkedIn headcount cross-referenced. Confirmed."},
    { text:"Founded in 2015",                        ok:true,  note:"MCA registration date confirmed."              },
    { text:"Won three industry awards this year",   ok:false, note:"Not verified. Listed only."                    },
  ];
  return (
    <section style={{ background:T.bg, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto", display:"grid", gridTemplateColumns:"1fr 1fr", gap:64, alignItems:"flex-start" }}>
        <div>
          <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:12 }}>For brands</p>
          <h2 style={{ fontFamily:T.serif, fontSize:32, color:T.ink, lineHeight:1.2, marginBottom:14 }}>Search any partner or brand.<br/>See what we found.</h2>
          <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7, marginBottom:24 }}>
            A partner says they worked with a leading FMCG company. Search them here. See whether that claim is independently verified or just a name on a deck. Free to search. No account needed.
          </p>
          <div style={{ display:"flex", marginBottom:12 }}>
            <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search any partner, creator, agency, or brand..."
              style={{ flex:1, background:T.bgWhite, border:`1px solid ${T.border}`, borderRight:"none", color:T.ink, fontFamily:T.sans, fontSize:13, padding:"11px 14px", outline:"none" }}/>
            <button style={{ background:T.ink, color:T.bg, border:"none", padding:"11px 20px", fontSize:12, cursor:"pointer", fontFamily:T.sans, fontWeight:600 }}>Search</button>
          </div>
          <p style={{ fontFamily:T.sans, fontSize:12, color:T.inkLight }}>
            Brand members see full score bands, reference contacts, and evidence packs.{" "}
            <span style={{ color:T.ink, textDecoration:"underline", cursor:"pointer" }}>Join as brand member →</span>
          </p>
        </div>
        <div>
          <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:12 }}>What verification actually checks</p>
          {claims.map((c,i)=>(
            <div key={i} style={{ display:"flex", alignItems:"flex-start", gap:10, padding:"11px 14px", background:T.bgWhite, border:`1px solid ${T.border}`, marginBottom:4 }}>
              <div style={{ width:18, height:18, flexShrink:0, background:c.ok?T.ink:"transparent", border:c.ok?"none":`1px solid ${T.border}`, display:"flex", alignItems:"center", justifyContent:"center", marginTop:1 }}>
                <span style={{ color:c.ok?T.bg:T.inkLight, fontSize:10 }}>{c.ok?"✓":"–"}</span>
              </div>
              <div style={{ flex:1 }}>
                <p style={{ fontFamily:T.sans, fontSize:13, color:T.ink, margin:"0 0 2px" }}>{c.text}</p>
                <p style={{ fontFamily:T.sans, fontSize:11, color:T.inkLight, margin:0 }}>{c.note}</p>
              </div>
              <Badge verified={c.ok}/>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { n:"01", title:"List free. Today.",       body:"Profile live the moment you submit. No queue. No approval. Discoverable immediately by brands searching right now." },
    { n:"02", title:"Apply for verification.", body:"Submit two references and evidence. The system contacts references independently — without routing through you. Automated. 5 to 7 days." },
    { n:"03", title:"Get found first.",        body:"Verified providers appear above listed-only in every search. Always. Permanently. No paid placement changes this. Ever." },
  ];
  return (
    <section style={{ background:T.bgWarm, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:40 }}>How it works</p>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:48 }}>
          {steps.map(s=>(
            <div key={s.n}>
              <p style={{ fontFamily:T.serif, fontSize:52, color:"rgba(10,9,8,0.08)", margin:"0 0 16px", lineHeight:1 }}>{s.n}</p>
              <h3 style={{ fontFamily:T.serif, fontSize:18, color:T.ink, marginBottom:10, lineHeight:1.3 }}>{s.title}</h3>
              <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7 }}>{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function StandardsTeaser() {
  const principles = [
    { n:"01", title:"References contacted directly",        body:"We email and call both references independently — without routing through you. They complete a structured seven-question form. You do not see their responses." },
    { n:"02", title:"Identity verified automatically",      body:"Company registration cross-checked against MCA and GSTN databases. LinkedIn headcount compared against claimed team size. Domain ownership confirmed." },
    { n:"03", title:"Evidence reviewed, not just accepted", body:"Case studies and results are assessed for internal consistency. Claims must be specific and measurable. Vague outcomes do not pass." },
    { n:"04", title:"Failure means a full refund",          body:"If you do not pass, you receive specific written feedback on exactly what failed and why. Your fee is refunded in full within 48 hours." },
  ];
  return (
    <section style={{ background:T.bg, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:36 }}>
          <div>
            <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:8 }}>Verification standards</p>
            <h2 style={{ fontFamily:T.serif, fontSize:28, color:T.ink, margin:0 }}>The badge means something.<br/>Here is why.</h2>
          </div>
          <span style={{ fontFamily:T.sans, fontSize:12, color:T.ink, textDecoration:"underline", cursor:"pointer", whiteSpace:"nowrap" }}>Read the full standard →</span>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:16 }}>
          {principles.map(p=>(
            <div key={p.n} style={{ background:T.bgWarm, border:`1px solid ${T.border}`, padding:"22px 24px" }}>
              <p style={{ fontFamily:T.serif, fontSize:28, color:"rgba(10,9,8,0.1)", margin:"0 0 12px", lineHeight:1 }}>{p.n}</p>
              <h4 style={{ fontFamily:T.serif, fontSize:15, color:T.ink, margin:"0 0 8px" }}>{p.title}</h4>
              <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7, margin:0 }}>{p.body}</p>
            </div>
          ))}
        </div>
        <div style={{ padding:"18px 22px", background:T.ink, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <p style={{ fontFamily:T.serif, fontSize:15, color:T.bg, margin:"0 0 3px" }}>Download the full SOP</p>
            <p style={{ fontFamily:T.sans, fontSize:11, color:"rgba(248,246,240,0.45)", margin:0 }}>10-section verification standard operating procedure. Public. Nothing hidden.</p>
          </div>
          <button style={{ background:T.bg, color:T.ink, border:"none", padding:"10px 18px", fontSize:12, cursor:"pointer", fontFamily:T.sans, fontWeight:600, flexShrink:0 }}>
            Download SOP →
          </button>
        </div>
      </div>
    </section>
  );
}

const ALL_CATEGORIES = [
  { group:"Agency Services",                count:60, items:["Performance Marketing","Paid Search","Paid Social","Programmatic Advertising","Affiliate Marketing","App Marketing & UA","Creative & Branding","Brand Strategy","Campaign Creative","Social Media Marketing","Community Management","Social Commerce","PR & Communications","Media Relations","Crisis Communications","Media Planning & Buying","TV Buying","OOH & DOOH","Content Marketing","SEO & Organic","Technical SEO","Influencer Marketing","Creator Commerce","UGC Campaigns","Event & Experiential","Brand Activations","Trade Shows","B2B Marketing","Account Based Marketing","Demand Generation","Martech Implementation","CRM Setup","Marketing Automation","E-commerce Marketing","D2C Growth","Marketplace Marketing","Rural & Bharat Marketing","Regional Language Marketing","Vernacular Content","Startup Marketing","Growth Hacking","Sports Marketing","Luxury Marketing","Healthcare Marketing","Pharma Marketing","Legal Marketing","Financial Services Marketing","Real Estate Marketing","Automotive Marketing","Sustainability Marketing","Cause Marketing","Political Campaigns","Government Communications","Shopper Marketing","Trade Marketing","Channel Marketing","Partner Marketing","Loyalty & Retention","Referral Marketing","Guerrilla Marketing"] },
  { group:"AdTech & MarTech Platforms",     count:40, items:["Demand Side Platforms (DSP)","Supply Side Platforms (SSP)","Data Management Platforms (DMP)","Customer Data Platforms (CDP)","Ad Exchanges & Networks","Programmatic Infrastructure","CRM Platforms","Marketing Automation Platforms","Email Marketing Platforms","SMS & WhatsApp Platforms","Push Notification Platforms","RCS Messaging Platforms","Attribution & MMP Platforms","Marketing Mix Modelling","Data Clean Rooms","Identity Resolution Platforms","Brand Safety Tools","Ad Fraud Detection","Viewability Measurement","Social Listening Platforms","SEO & Content Tools","A/B Testing Platforms","Heatmap & Session Recording","CRO Tools","Landing Page Platforms","Marketing Asset Management","Customer Journey Platforms","Loyalty Platform Providers","Referral Marketing Platforms","Chatbot Platforms","Retail Media Networks","In-game Advertising","Connected TV Platforms","Audio Advertising Platforms","Digital OOH Tech","Location Intelligence","Revenue Intelligence","Sales Intelligence Tools","Intent Data Providers","B2B Data & Contact Enrichment"] },
  { group:"Data, Research & Measurement",  count:25, items:["Market Research","Brand Tracking Studies","Consumer Insight & Ethnography","Focus Group Facilities","UX Research for Marketing","Competitive Intelligence","Audience Measurement","Social Media Analytics","Customer Journey Mapping","Persona Research","Pricing Research","Product-Market Fit Research","Media Effectiveness Research","Ad Testing & Pre-testing","Post-campaign Measurement","ROMI Measurement","Marketing Attribution Consulting","Data Strategy Consulting","First-party Data Strategy","Panel Research","In-home Usage Tests","Mystery Shopping","Retail Audit","Neuromarketing Research","Eye-tracking Research"] },
  { group:"Creators & Talent",              count:50, items:["Instagram Creators — Fashion","Instagram Creators — Finance","Instagram Creators — Food","Instagram Creators — Fitness","Instagram Creators — Travel","Instagram Creators — Tech","Instagram Creators — Beauty","YouTube Creators — Tech Reviews","YouTube Creators — Personal Finance","YouTube Creators — Food","YouTube Creators — Gaming","YouTube Creators — Education","LinkedIn Thought Leaders — Marketing","LinkedIn Thought Leaders — Startup","LinkedIn Thought Leaders — Finance","Podcast Hosts — Business","Podcast Hosts — True Crime","Podcast Hosts — Finance","Podcast Hosts — Technology","Short-form Video Creators","Newsletter Creators","Twitter / X Voices","WhatsApp Community Leaders","Meme & Entertainment Accounts","Sports Commentary Creators","Regional Language Creators","Vernacular Content Creators"] },
  { group:"Independent Professionals",      count:35, items:["Fractional CMO","Fractional Chief Brand Officer","Growth Advisor","Brand Strategist","Go-to-Market Specialist","Category Strategy Consultant","Media Planner","PR Consultant","SEO Consultant","Performance Marketing Consultant","Content Strategist","CRO Specialist","MarTech Consultant","Marketing Analyst","Marketing Data Scientist","CRM Specialist","B2B Marketing Specialist","Interim Marketing Director","Startup Marketing Advisor","Sports Marketing Consultant","Luxury Marketing Consultant","Rural Marketing Specialist","Vernacular Marketing Specialist","Influencer Marketing Consultant","Brand Naming Consultant","Packaging Design Consultant","Customer Experience Consultant","Marketing Trainer & Coach","Investor Relations Consultant","Political Campaign Consultant"] },
  { group:"Production & Creative Services", count:30, items:["Video Production","Photography","Motion Graphics & Animation","3D & CGI","Sound Design","Music Licensing","Voiceover Artists","Translation & Localisation","Podcast Production","AR & VR Experiences","Interactive Content","Gamification","Brand Naming","Packaging Design","Typography & Type Design","Illustration","Graphic Design","UI/UX for Marketing","Retail Design","Exhibition Design","Print Production","Merchandise Design"] },
  { group:"Events & Experiential",          count:20, items:["Corporate Event Management","Product Launch Specialists","Brand Activations","Trade Show & Exhibition","Pop-up Retail","Sampling Campaigns","Sports Sponsorship Management","Entertainment Marketing","Virtual Event Production","Hybrid Event Management","Retail Activation","Shopper Marketing","Road Shows","Fan Engagement","Concerts & Live Events","Awards & Ceremonies"] },
  { group:"Media & Publishing",             count:15, items:["Digital Publishers","Podcast Networks","OTT Platforms","Out-of-Home Networks","Radio Networks","Print Media","Industry Newsletters","Content Platforms","Niche Media Owners","Regional Language Media","Community Media"] },
  { group:"Specialised & Emerging",         count:20, items:["AI Marketing Tools","Gaming & Esports Marketing","Web3 & NFT Marketing","Conversational Marketing","Community Building","Alliance Marketing","Ambassador Programme Management","Cause Marketing","Sustainability Marketing","Metaverse Activations","NFT Marketing","Crypto Marketing","D2C Enablement","Quick Commerce Marketing","Revenue Operations","Customer Success Marketing"] },
];

function CategoriesSection() {
  const [expanded,setExpanded] = useState(null);
  const total = ALL_CATEGORIES.reduce((a,g)=>a+g.count,0);
  return (
    <section style={{ background:T.bgWarm, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:32 }}>
          <div>
            <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:8 }}>Browse by category</p>
            <h2 style={{ fontFamily:T.serif, fontSize:28, color:T.ink, margin:0 }}>If you work in marketing, you belong here.</h2>
          </div>
          <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkLight, margin:0 }}>{total}+ categories across 9 groups</p>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:4 }}>
          {ALL_CATEGORIES.map((g,i)=>(
            <div key={g.group} onClick={()=>setExpanded(expanded===i?null:i)}
              style={{ background:expanded===i?T.ink:T.bgWhite, border:`1px solid ${T.border}`, padding:"14px 16px", cursor:"pointer", transition:"all 0.2s" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:expanded===i?10:0 }}>
                <p style={{ fontFamily:T.sans, fontSize:13, color:expanded===i?T.bg:T.ink, fontWeight:600, margin:0 }}>{g.group}</p>
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <span style={{ fontFamily:T.sans, fontSize:10, color:expanded===i?"rgba(248,246,240,0.5)":T.inkLight }}>{g.count}+</span>
                  <span style={{ color:expanded===i?T.bg:T.inkLight, fontSize:11 }}>{expanded===i?"↑":"↓"}</span>
                </div>
              </div>
              {expanded===i && (
                <div style={{ display:"flex", flexWrap:"wrap", gap:4 }}>
                  {g.items.map(s=>(
                    <span key={s} style={{ fontFamily:T.sans, fontSize:10, color:"rgba(248,246,240,0.65)", background:"rgba(248,246,240,0.07)", padding:"3px 7px", cursor:"pointer" }}>{s}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

const FAQS = [
  { q:"Is listing really free?",                                    a:"Yes. Completely free. No credit card. No trial period. Your profile goes live immediately when you submit. Listing is the entry point — verification is the separate paid step for those who want the badge." },
  { q:"How long does verification take?",                           a:"5 to 7 working days for standard applications where both references respond promptly. If references take longer to respond the system follows up automatically on day 5 and day 10. Maximum window is 21 days." },
  { q:"What if my company registration is not in the MCA system?",  a:"Very common for proprietorships, older companies, and LLPs with incomplete digital records. The system flags it and asks you to upload your certificate of incorporation. A reviewer confirms within 48 hours. Your application is not rejected — identity check falls back to manual." },
  { q:"Are my references contacted without my involvement?",        a:"Yes. We contact them directly using the email you provide. We do not route the communication through you. We do not show you what they said. We do not share your self-assessment with them before asking questions. Independence is the point." },
  { q:"What happens if I fail verification?",                       a:"You receive specific written feedback on exactly which criteria did not pass and what would need to change. Your fee is refunded in full within 48 hours. Your listing continues exactly as before. Nothing is disclosed publicly. You can reapply at any time." },
  { q:"Who can see my score band?",                                  a:"Brand members only — those who have paid for the brand membership tier. Your public profile shows only the Few Found Verified mark with no score visible. The score is private intelligence for serious buyers." },
  { q:"Can a brand see who reviewed them?",                         a:"No. Brand reviews are anonymous to the brand. The reviewer's identity is known to Few Found but not shared. This is the Glassdoor model — anonymity is what makes honest reviews possible." },
  { q:"Is there any paid placement in search results?",             a:"No. Verified providers always appear above listed-only providers. Within verified, order is by most recently reviewed. There is no sponsored position, no featured placement, no way to pay for higher visibility. This is hardcoded and cannot be changed from the admin panel." },
  { q:"Can I list if I am a solo freelancer with no company?",      a:"Yes. Independent professionals list as individuals. No company registration required. Identity verification uses LinkedIn history and reference confirmation. The tier achieved reflects the available identity signal." },
  { q:"What does brand membership give me?",                        a:"Full verified profiles with score bands, reference contact details, and evidence packs. Access to the shortlist service — submit a brief and receive a curated shortlist of matching verified providers. And access to brand review data showing how partners rate brands as clients." },
];

function FAQSection() {
  const [open,setOpen] = useState(null);
  return (
    <section style={{ background:T.bg, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 2fr", gap:64 }}>
          <div>
            <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:12 }}>FAQs</p>
            <h2 style={{ fontFamily:T.serif, fontSize:28, color:T.ink, lineHeight:1.3, marginBottom:16 }}>Every question a sceptic would ask. Answered honestly.</h2>
            <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7, marginBottom:24 }}>
              If something is not covered here, ask us on WhatsApp. We respond personally.
            </p>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer"
              style={{ display:"inline-flex", alignItems:"center", gap:8, background:"#25D366", color:"white", padding:"10px 16px", textDecoration:"none", fontFamily:T.sans, fontSize:12, fontWeight:600 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
              Ask on WhatsApp
            </a>
          </div>
          <div>
            {FAQS.map((f,i)=>(
              <div key={i} style={{ borderBottom:`1px solid ${T.border}` }}>
                <button onClick={()=>setOpen(open===i?null:i)}
                  style={{ width:"100%", display:"flex", justifyContent:"space-between", alignItems:"center", padding:"15px 0", background:"transparent", border:"none", cursor:"pointer", textAlign:"left" }}>
                  <span style={{ fontFamily:T.serif, fontSize:15, color:T.ink }}>{f.q}</span>
                  <span style={{ color:T.inkLight, fontSize:18, flexShrink:0, marginLeft:16 }}>{open===i?"−":"+"}</span>
                </button>
                {open===i && <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7, paddingBottom:15, margin:0 }}>{f.a}</p>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

const PUBLICATIONS = [
  { name:"Economic Times Brandwagon", abbr:"ET"  },
  { name:"Afaqs",                     abbr:"AF"  },
  { name:"Campaign India",            abbr:"CI"  },
  { name:"Storyboard18",              abbr:"SB"  },
  { name:"Inc42",                     abbr:"I42" },
  { name:"The Ken",                   abbr:"TK"  },
  { name:"Morning Context",           abbr:"MC"  },
];

function MediaSection() {
  return (
    <section style={{ background:T.bgWarm, borderBottom:`1px solid ${T.border}`, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:64, alignItems:"center" }}>
          <div>
            <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:12 }}>Press & media</p>
            <h2 style={{ fontFamily:T.serif, fontSize:28, color:T.ink, lineHeight:1.3, marginBottom:14 }}>The story is getting out.</h2>
            <p style={{ fontFamily:T.sans, fontSize:13, color:T.inkMid, lineHeight:1.7, marginBottom:24 }}>
              We are in conversation with India's leading marketing publications. If you are a journalist or editor and want to cover the story of trust infrastructure for India's marketing ecosystem, reach out directly.
            </p>
            <div style={{ display:"flex", gap:10 }}>
              <a href="mailto:press@fewfound.co"
                style={{ display:"inline-block", background:T.ink, color:T.bg, padding:"10px 18px", textDecoration:"none", fontFamily:T.sans, fontSize:12, fontWeight:600 }}>
                Press enquiries →
              </a>
              <button style={{ background:"transparent", border:`1px solid ${T.ink}`, color:T.ink, padding:"10px 18px", fontSize:12, cursor:"pointer", fontFamily:T.sans }}>
                Download press kit
              </button>
            </div>
          </div>
          <div>
            <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:14 }}>Publications we are talking to</p>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>
              {PUBLICATIONS.map(pub=>(
                <div key={pub.name} style={{ display:"flex", alignItems:"center", gap:10, padding:"11px 13px", background:T.bgWhite, border:`1px solid ${T.border}` }}>
                  <div style={{ width:28, height:28, background:T.bgWarm, border:`1px solid ${T.border}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <span style={{ fontFamily:T.mono, fontSize:8, color:T.inkMid, fontWeight:700 }}>{pub.abbr}</span>
                  </div>
                  <p style={{ fontFamily:T.sans, fontSize:11, color:T.ink, margin:0, lineHeight:1.3 }}>{pub.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function TheRule() {
  return (
    <section style={{ background:T.ink, padding:"64px 48px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ maxWidth:640 }}>
          <p style={{ fontFamily:T.sans, fontSize:10, color:"rgba(248,246,240,0.25)", letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:20 }}>The one rule</p>
          <blockquote style={{ fontFamily:T.serif, fontSize:22, color:T.bg, lineHeight:1.6, borderLeft:`2px solid ${T.gold}`, paddingLeft:24, margin:"0 0 20px" }}>
            Verified providers always appear above listed-only providers in every search. No provider can pay to appear higher. No sponsored results. Ever.
          </blockquote>
          <p style={{ fontFamily:T.sans, fontSize:12, color:"rgba(248,246,240,0.35)", margin:"0 0 32px" }}>Hardcoded into the database query. Cannot be changed from any admin panel.</p>
          <div style={{ display:"flex", gap:12, alignItems:"center" }}>
            <button style={{ background:T.bg, color:T.ink, border:"none", padding:"12px 24px", fontSize:13, cursor:"pointer", fontFamily:T.sans, fontWeight:600 }}>List your profile free</button>
            <span style={{ fontFamily:T.sans, fontSize:13, color:"rgba(248,246,240,0.38)", textDecoration:"underline", cursor:"pointer" }}>Apply for verification →</span>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const cols = [
    { title:"Browse",  links:["All agencies","All creators","All professionals","AdTech platforms","Brand partners","Review a brand"] },
    { title:"Cities",  links:["Mumbai","Delhi","Bengaluru","Hyderabad","Chennai","Pune","Kolkata","Gurugram"] },
    { title:"Company", links:["About","How it works","Verification standards","For brands","Press & media","Download SOP","List your profile"] },
  ];
  return (
    <footer style={{ background:T.bg, borderTop:`1px solid ${T.border}`, padding:"48px 48px 32px" }}>
      <div style={{ maxWidth:1080, margin:"0 auto" }}>
        <div style={{ display:"grid", gridTemplateColumns:"1.2fr 1fr 1fr 1fr", gap:40, marginBottom:40 }}>
          <div>
            <Wordmark size="sm"/>
            <p style={{ fontFamily:T.sans, fontSize:12, color:T.inkLight, lineHeight:1.6, marginTop:12, maxWidth:200 }}>India's trust layer for marketing service providers.</p>
            <a href="https://wa.me/919999999999" target="_blank" rel="noopener noreferrer"
              style={{ display:"inline-flex", alignItems:"center", gap:6, marginTop:14, textDecoration:"none" }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
              <span style={{ fontFamily:T.sans, fontSize:11, color:"#25D366" }}>WhatsApp us</span>
            </a>
          </div>
          {cols.map(col=>(
            <div key={col.title}>
              <p style={{ fontFamily:T.sans, fontSize:10, color:T.inkLight, letterSpacing:"0.12em", textTransform:"uppercase", marginBottom:14 }}>{col.title}</p>
              {col.links.map(l=><p key={l} style={{ fontFamily:T.sans, fontSize:12, color:T.inkMid, marginBottom:8, cursor:"pointer" }}>{l}</p>)}
            </div>
          ))}
        </div>
        <div style={{ borderTop:`1px solid ${T.border}`, paddingTop:20, display:"flex", justifyContent:"space-between" }}>
          <p style={{ fontFamily:T.sans, fontSize:11, color:T.inkLight, margin:0 }}>© 2026 Few Found. All rights reserved.</p>
          <p style={{ fontFamily:T.sans, fontSize:11, color:T.inkLight, margin:0 }}>Verified providers are independently assessed. No paid placement.</p>
        </div>
      </div>
    </footer>
  );
}

function QABar({ onApprove }) {
  const [note,setNote] = useState(""); const [open,setOpen] = useState(false); const [done,setDone] = useState(false);
  if(done) return <div style={{ position:"fixed", bottom:0, left:0, right:210, background:"#0a2a0a", borderTop:"1px solid #1a4a1a", padding:"12px 24px", zIndex:999 }}><span style={{ fontFamily:T.mono, fontSize:11, color:"#4ade80" }}>✓ SCREEN 1 APPROVED — Building Screen 2: Type Selection</span></div>;
  return (
    <div style={{ position:"fixed", bottom:0, left:0, right:210, background:"#111", borderTop:"1px solid #222", padding:"11px 24px", display:"flex", justifyContent:"space-between", alignItems:"center", zIndex:999 }}>
      <div style={{ display:"flex", gap:14, alignItems:"center" }}>
        <span style={{ fontFamily:T.mono, fontSize:9, color:"#555" }}>WIREFRAME QA — SCREEN 1 / HOMEPAGE</span>
        <span style={{ fontFamily:T.mono, fontSize:9, color:"#FF6B35", background:"#1a0a00", padding:"2px 7px" }}>INTERNAL — NOT ON LIVE SITE</span>
      </div>
      <div style={{ display:"flex", gap:10 }}>
        <button onClick={()=>setOpen(!open)} style={{ background:"transparent", color:"#888", border:"1px solid #333", padding:"6px 14px", fontSize:11, cursor:"pointer", fontFamily:T.mono }}>Request change</button>
        <button onClick={()=>{ setDone(true); onApprove&&onApprove(); }} style={{ background:"#FF6B35", color:"#fff", border:"none", padding:"6px 18px", fontSize:11, fontWeight:700, cursor:"pointer", fontFamily:T.mono }}>APPROVE → Screen 2</button>
      </div>
      {open && (
        <div style={{ position:"absolute", bottom:54, right:16, background:"#1a1a1a", border:"1px solid #333", padding:14, width:290, borderRadius:4 }}>
          <p style={{ color:"#FF6B35", fontSize:9, fontFamily:T.mono, margin:"0 0 8px", letterSpacing:"0.1em" }}>WHAT NEEDS CHANGING</p>
          <textarea value={note} onChange={e=>setNote(e.target.value)} rows={4} placeholder="Describe the change..."
            style={{ width:"100%", background:"#0a0a0a", border:"1px solid #333", color:"#ccc", padding:8, fontSize:11, fontFamily:T.mono, resize:"none", boxSizing:"border-box" }}/>
          <button onClick={()=>{ alert(`Change logged:\n"${note}"\n\nFixed before Screen 2.`); setNote(""); setOpen(false); }}
            style={{ marginTop:8, width:"100%", background:"#222", color:"#ccc", border:"1px solid #333", padding:7, fontSize:11, cursor:"pointer", fontFamily:T.mono }}>Submit →</button>
        </div>
      )}
    </div>
  );
}

const SCREENS = ["Homepage","Type Selection","Quick Capture Form","Auth — Social / Email","Dashboard — Post Listing","Profile Completion — Services","Profile Completion — Clients","Profile Completion — Bio & Details","Verification Application","Reference Submission","Evidence Upload","Verification Progress Tracker","Payment Flow","Verification Success","Provider Profile — Public","Search Results","Category — Populated","Category — Empty State","Brand Membership","Brand Dashboard","Client Record Filing","Admin Dashboard"];

function ScreenMap({ approved }) {
  return (
    <div style={{ position:"fixed", right:0, top:0, bottom:0, width:210, background:"#0d0d0d", borderLeft:"1px solid #1a1a1a", overflowY:"auto", zIndex:300 }}>
      <div style={{ padding:"14px", borderBottom:"1px solid #1a1a1a" }}>
        <p style={{ color:"#FF6B35", fontSize:9, fontWeight:700, fontFamily:T.mono, margin:0, letterSpacing:"0.1em" }}>SCREEN MAP</p>
        <p style={{ color:"#444", fontSize:9, fontFamily:T.mono, margin:"4px 0 0" }}>{approved}/{SCREENS.length} approved</p>
      </div>
      {SCREENS.map((s,i)=>(
        <div key={i} style={{ padding:"7px 14px", display:"flex", alignItems:"flex-start", gap:8, background:i===0?"#1a1a1a":"transparent", borderLeft:`2px solid ${i===0?"#FF6B35":"transparent"}` }}>
          <div style={{ width:10, height:10, borderRadius:"50%", flexShrink:0, marginTop:3, background:i<approved?"#4ade80":i===0?"#FF6B35":"#222", border:i<approved||i===0?"none":"1px solid #333" }}/>
          <p style={{ fontFamily:T.mono, fontSize:8.5, lineHeight:1.5, margin:0, color:i<approved?"#4ade80":i===0?"#ddd":"#3a3a3a" }}>{i+1}. {s}</p>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [approved,setApproved] = useState(0);
  return (
    <div style={{ marginRight:210 }}>
      <Nav/>
      <Hero/>
      <BrandsSection/>
      <PartnersSection/>
      <SearchSection/>
      <HowItWorks/>
      <StandardsTeaser/>
      <CategoriesSection/>
      <FAQSection/>
      <MediaSection/>
      <TheRule/>
      <Footer/>
      <WhatsAppButton/>
      <div style={{ height:60 }}/>
      <QABar onApprove={()=>setApproved(1)}/>
      <ScreenMap approved={approved}/>
    </div>
  );
}
