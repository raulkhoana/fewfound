import { useState, useEffect } from "react";

// ─── COMPLETE CATEGORY SYSTEM ──────────────────────────────────────────────
const CATEGORIES = {
  agency: {
    label: "Agency",
    icon: "◆",
    subcategories: [
      {
        group: "Performance & Growth",
        items: [
          "Performance Marketing",
          "Paid Search (Google / Bing)",
          "Paid Social (Meta / LinkedIn / X)",
          "Programmatic Display & Video",
          "Affiliate Marketing",
          "App Marketing & User Acquisition",
          "CTV & OTT Advertising",
          "Retargeting & Remarketing",
          "Marketplace Ads (Amazon / Flipkart)",
          "Growth Marketing",
          "Conversion Rate Optimisation",
          "E-commerce Marketing",
          "D2C Marketing",
          "Quick Commerce Marketing",
        ],
      },
      {
        group: "Creative & Brand",
        items: [
          "Brand Strategy",
          "Creative & Branding",
          "Visual Identity & Logo Design",
          "Campaign Creative",
          "Packaging Design",
          "Brand Architecture",
          "Rebranding",
          "Copywriting",
          "Motion Graphics & Animation",
          "Video Production",
          "Photography",
          "3D & CGI",
          "UI/UX for Marketing",
          "AR / VR Marketing",
        ],
      },
      {
        group: "Content & SEO",
        items: [
          "Content Marketing",
          "SEO & Organic Search",
          "Technical SEO",
          "Link Building",
          "Local SEO",
          "Blog & Article Writing",
          "Podcast Production",
          "Newsletter Management",
          "White Papers & Case Studies",
          "Vernacular Content",
        ],
      },
      {
        group: "Social & Influencer",
        items: [
          "Social Media Marketing",
          "Community Management",
          "Social Commerce",
          "Influencer & Creator Marketing",
          "UGC Campaigns",
          "Celebrity Management",
          "Micro-influencer Programs",
          "Creator Commerce",
        ],
      },
      {
        group: "Media & PR",
        items: [
          "Media Planning & Buying",
          "TV Media Buying",
          "Print & Radio",
          "OOH & DOOH",
          "Integrated Media Planning",
          "PR & Communications",
          "Media Relations",
          "Crisis Communications",
          "Executive Profiling",
          "Investor Relations",
          "Reputation Management",
          "Government & Public Affairs",
        ],
      },
      {
        group: "Martech & Data",
        items: [
          "Martech & Analytics",
          "CRM Implementation",
          "Marketing Automation",
          "CDP Implementation",
          "Data Architecture",
          "Attribution Modelling",
          "Analytics & BI Dashboards",
          "Tag Management",
          "Customer Journey Analytics",
        ],
      },
      {
        group: "B2B & Specialised",
        items: [
          "B2B Marketing",
          "Account Based Marketing (ABM)",
          "Demand Generation",
          "Lead Generation",
          "Sales Enablement",
          "Event & Experiential Marketing",
          "Product Launches",
          "Trade Shows & Exhibitions",
          "Retail Activations",
          "Sports Marketing",
          "Luxury Marketing",
          "Healthcare Marketing",
          "Pharma Marketing",
          "Real Estate Marketing",
          "EdTech Marketing",
          "FinTech Marketing",
          "Rural & Bharat Marketing",
          "Regional Language Marketing",
          "Political Campaign Management",
          "Startup Marketing",
          "IPO & Financial Marketing",
          "Cause Marketing & CSR",
        ],
      },
    ],
  },
  creator: {
    label: "Creator",
    icon: "◉",
    subcategories: [
      {
        group: "Instagram",
        items: [
          "Fashion & Style",
          "Beauty & Skincare",
          "Food & Recipes",
          "Travel & Lifestyle",
          "Personal Finance",
          "Tech & Gadgets",
          "Fitness & Wellness",
          "Parenting & Family",
          "Comedy & Entertainment",
          "Business & Entrepreneurship",
          "Education & How-to",
          "Home & Décor",
          "Sustainability",
          "Gaming",
          "Automotive",
          "Luxury & Premium",
          "Regional & Vernacular",
        ],
      },
      {
        group: "YouTube",
        items: [
          "Tech Reviews & Unboxing",
          "Personal Finance & Investing",
          "Food & Cooking",
          "Travel Vlogs",
          "Gaming & Esports",
          "Education & Explainers",
          "Comedy & Entertainment",
          "Fitness & Health",
          "Beauty Tutorials",
          "Business & Startup",
          "Auto Reviews",
          "Interviews & Podcasts",
          "Regional Language Content",
          "Kids & Family",
        ],
      },
      {
        group: "LinkedIn",
        items: [
          "Marketing & Advertising",
          "Sales & Business Development",
          "Startups & Entrepreneurship",
          "HR & People Management",
          "Technology & Product",
          "Finance & Investment",
          "Leadership & Management",
          "Career Advice",
          "Legal & Compliance",
          "Consulting & Strategy",
        ],
      },
      {
        group: "Podcast",
        items: [
          "Business & Entrepreneurship",
          "True Crime",
          "Personal Finance",
          "Technology",
          "Health & Wellness",
          "Sports",
          "Entertainment & Pop Culture",
          "Education & Self-help",
          "Politics & Current Affairs",
          "Comedy",
          "Marketing & Advertising",
        ],
      },
      {
        group: "Short-form & Emerging",
        items: [
          "Reels & YouTube Shorts",
          "Meme Accounts",
          "News & Current Affairs",
          "Sports Commentary",
          "WhatsApp Community Creator",
          "Newsletter Creator",
          "Twitter / X Influencer",
          "Forum & Reddit",
        ],
      },
    ],
  },
  professional: {
    label: "Professional",
    icon: "◈",
    subcategories: [
      {
        group: "Strategy & Leadership",
        items: [
          "Fractional CMO",
          "Fractional Chief Brand Officer",
          "Marketing Consultant",
          "Brand Strategist",
          "Go-to-Market Specialist",
          "Category Strategy Consultant",
          "Customer Experience Consultant",
          "Marketing Trainer & Coach",
        ],
      },
      {
        group: "Performance & Growth",
        items: [
          "Growth Advisor",
          "Performance Marketing Consultant",
          "E-commerce Growth Specialist",
          "D2C Specialist",
          "App Growth Consultant",
          "Marketplace Specialist",
          "SEO Consultant",
          "CRO Specialist",
        ],
      },
      {
        group: "Content & Creative",
        items: [
          "Freelance Creative Director",
          "Content Strategist",
          "Freelance Copywriter",
          "Brand Naming Consultant",
          "Packaging Design Consultant",
          "Freelance Videographer",
          "Freelance Photographer",
          "Motion Designer",
        ],
      },
      {
        group: "Media & PR",
        items: [
          "Independent Media Planner",
          "Media Buying Specialist",
          "PR Consultant",
          "Crisis Communication Advisor",
          "Reputation Management Consultant",
          "Influencer Marketing Consultant",
        ],
      },
      {
        group: "Data & Technology",
        items: [
          "Marketing Analyst",
          "Marketing Data Scientist",
          "CRM Specialist",
          "MarTech Consultant",
          "Marketing Automation Specialist",
          "Attribution Consultant",
        ],
      },
      {
        group: "Specialised",
        items: [
          "Interim Marketing Director",
          "B2B Marketing Specialist",
          "Healthcare Marketing Advisor",
          "FinTech Marketing Specialist",
          "EdTech Marketing Specialist",
          "Startup Advisor (Marketing)",
          "Investor Relations Consultant",
          "Political Campaign Consultant",
          "Sports Marketing Consultant",
          "Luxury Marketing Consultant",
          "Rural Marketing Specialist",
          "Vernacular Marketing Specialist",
        ],
      },
    ],
  },
  brand: {
    label: "Brand",
    icon: "◇",
    subcategories: [
      {
        group: "Consumer",
        items: [
          "D2C Brand",
          "FMCG",
          "Fashion & Apparel",
          "Beauty & Personal Care",
          "Food & Beverage",
          "Home & Living",
          "Baby & Parenting",
          "Luxury & Premium",
          "Sports & Outdoor",
          "Automotive",
          "Pet Care",
        ],
      },
      {
        group: "Technology",
        items: [
          "Consumer Tech",
          "SaaS",
          "FinTech",
          "EdTech",
          "HealthTech",
          "AgriTech",
          "CleanTech",
          "Mobility & EV",
          "Gaming & Esports",
          "E-commerce & Marketplace",
          "Quick Commerce",
        ],
      },
      {
        group: "Services",
        items: [
          "Financial Services",
          "Insurance",
          "Real Estate",
          "Healthcare & Hospital",
          "Pharma",
          "Education & Training",
          "Travel & Hospitality",
          "Retail Chain",
          "Restaurant & QSR",
          "Entertainment & OTT",
          "Media & Publishing",
        ],
      },
      {
        group: "B2B",
        items: [
          "B2B Technology",
          "Professional Services",
          "Manufacturing",
          "Infrastructure",
          "Industrial",
          "NGO & Non-profit",
          "Government & PSU",
          "Startup (Pre-revenue)",
          "Startup (Revenue stage)",
        ],
      },
    ],
  },
};

// ─── SCREEN REGISTRY ───────────────────────────────────────────────────────
const SCREENS = [
  { id: 1, name: "Homepage", status: "current" },
  { id: 2, name: "Type Selection", status: "pending" },
  { id: 3, name: "Quick Capture Form", status: "pending" },
  { id: 4, name: "Auth — Google / LinkedIn / Email", status: "pending" },
  { id: 5, name: "Dashboard — Post Listing", status: "pending" },
  { id: 6, name: "Profile Completion — Services", status: "pending" },
  { id: 7, name: "Profile Completion — Clients", status: "pending" },
  { id: 8, name: "Profile Completion — Bio & Details", status: "pending" },
  { id: 9, name: "Verification Application", status: "pending" },
  { id: 10, name: "Reference Submission", status: "pending" },
  { id: 11, name: "Evidence Upload", status: "pending" },
  { id: 12, name: "Verification Progress Tracker", status: "pending" },
  { id: 13, name: "Payment Flow", status: "pending" },
  { id: 14, name: "Verification Success", status: "pending" },
  { id: 15, name: "Provider Profile — Public View", status: "pending" },
  { id: 16, name: "Search Results Page", status: "pending" },
  { id: 17, name: "Category Page — Populated", status: "pending" },
  { id: 18, name: "Category Page — Empty State", status: "pending" },
  { id: 19, name: "Brand Membership Page", status: "pending" },
  { id: 20, name: "Brand Dashboard", status: "pending" },
  { id: 21, name: "Client Record Filing", status: "pending" },
  { id: 22, name: "Admin Dashboard", status: "pending" },
];

// ─── ANNOTATION COMPONENT ─────────────────────────────────────────────────
function Annotation({ number, text, position = "right" }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative inline-flex items-center" style={{ zIndex: 100 }}>
      <button
        onClick={() => setShow(!show)}
        style={{
          width: 20, height: 20, borderRadius: "50%",
          backgroundColor: "#FF6B35", color: "white",
          border: "none", fontSize: 10, fontWeight: 700,
          cursor: "pointer", flexShrink: 0,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "monospace",
        }}
      >
        {number}
      </button>
      {show && (
        <div style={{
          position: "absolute",
          [position === "right" ? "left" : "right"]: 26,
          top: "50%", transform: "translateY(-50%)",
          backgroundColor: "#1a1a1a", color: "white",
          padding: "8px 12px", borderRadius: 4,
          fontSize: 11, lineHeight: 1.5, width: 220,
          zIndex: 200, fontFamily: "monospace",
          boxShadow: "0 4px 20px rgba(0,0,0,0.4)",
        }}>
          <div style={{ fontWeight: 700, marginBottom: 4, color: "#FF6B35" }}>
            Note {number}
          </div>
          {text}
        </div>
      )}
    </div>
  );
}

// ─── WIREFRAME SHELL ──────────────────────────────────────────────────────
function WireframeShell({ screenId, screenName, children, onApprove, onRequestChange, approved }) {
  const [changeNote, setChangeNote] = useState("");
  const [showChangeForm, setShowChangeForm] = useState(false);

  return (
    <div style={{ fontFamily: "'IBM Plex Mono', monospace", backgroundColor: "#0a0a0a", minHeight: "100vh" }}>
      {/* Top bar */}
      <div style={{
        backgroundColor: "#111", borderBottom: "1px solid #222",
        padding: "10px 20px", display: "flex", alignItems: "center",
        justifyContent: "space-between", position: "sticky", top: 0, zIndex: 500,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ color: "#FF6B35", fontWeight: 700, fontSize: 12 }}>FEW FOUND</div>
          <div style={{ color: "#444", fontSize: 12 }}>WIREFRAME SYSTEM</div>
          <div style={{ color: "#333", fontSize: 12 }}>v1.0</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ color: "#555", fontSize: 11 }}>
            SCREEN {screenId} / {SCREENS.length} — {screenName}
          </div>
          {approved ? (
            <div style={{
              backgroundColor: "#1a3a1a", color: "#4ade80",
              padding: "4px 12px", fontSize: 11, fontWeight: 700,
              letterSpacing: "0.1em",
            }}>
              ✓ APPROVED
            </div>
          ) : (
            <div style={{
              backgroundColor: "#2a1a00", color: "#FF6B35",
              padding: "4px 12px", fontSize: 11, fontWeight: 700,
              letterSpacing: "0.1em",
            }}>
              AWAITING APPROVAL
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      <div>{children}</div>

      {/* Approval bar */}
      {!approved && (
        <div style={{
          position: "fixed", bottom: 0, left: 0, right: 0,
          backgroundColor: "#111", borderTop: "1px solid #222",
          padding: "16px 24px", display: "flex", alignItems: "center",
          justifyContent: "space-between", zIndex: 500,
        }}>
          <div style={{ color: "#555", fontSize: 11 }}>
            ● Click annotations <span style={{ color: "#FF6B35" }}>①</span> to read design notes &nbsp;·&nbsp;
            Review all elements before approving
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button
              onClick={() => setShowChangeForm(!showChangeForm)}
              style={{
                backgroundColor: "transparent", color: "#888",
                border: "1px solid #333", padding: "8px 20px",
                fontSize: 12, cursor: "pointer", fontFamily: "monospace",
              }}
            >
              Request change
            </button>
            <button
              onClick={onApprove}
              style={{
                backgroundColor: "#FF6B35", color: "white",
                border: "none", padding: "8px 24px",
                fontSize: 12, cursor: "pointer", fontWeight: 700,
                fontFamily: "monospace", letterSpacing: "0.05em",
              }}
            >
              APPROVE → SCREEN {screenId + 1}
            </button>
          </div>
        </div>
      )}

      {showChangeForm && (
        <div style={{
          position: "fixed", bottom: 60, right: 24,
          backgroundColor: "#1a1a1a", border: "1px solid #333",
          padding: 16, width: 320, zIndex: 600,
        }}>
          <div style={{ color: "#FF6B35", fontSize: 11, fontWeight: 700, marginBottom: 8 }}>
            REQUEST CHANGE
          </div>
          <textarea
            value={changeNote}
            onChange={e => setChangeNote(e.target.value)}
            placeholder="Describe what needs to change..."
            style={{
              width: "100%", height: 80, backgroundColor: "#0a0a0a",
              border: "1px solid #333", color: "#ccc", padding: 8,
              fontSize: 12, fontFamily: "monospace", resize: "none",
            }}
          />
          <button
            onClick={() => {
              onRequestChange(changeNote);
              setChangeNote("");
              setShowChangeForm(false);
            }}
            style={{
              marginTop: 8, width: "100%", backgroundColor: "#222",
              color: "#ccc", border: "1px solid #333", padding: "8px",
              fontSize: 12, cursor: "pointer", fontFamily: "monospace",
            }}
          >
            Submit change request
          </button>
        </div>
      )}
    </div>
  );
}

// ─── SCREEN 1: HOMEPAGE ───────────────────────────────────────────────────
function Screen1Homepage({ onApprove, onRequestChange, approved }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [hoveredType, setHoveredType] = useState(null);
  const [stats] = useState({ listed: 247, verified: 89, brands: 34 });

  const types = [
    { id: "agency", label: "List as agency", desc: "Performance, creative, PR, media, martech, affiliate", fomo: "Verified agencies already receiving brand enquiries" },
    { id: "creator", label: "List as creator", desc: "YouTube, Instagram, LinkedIn, podcast, short-form", fomo: "Verified creators appearing in brand shortlists now" },
    { id: "professional", label: "List as professional", desc: "Fractional CMO, strategist, growth advisor", fomo: "The category brands are searching hardest for" },
    { id: "brand", label: "List as brand", desc: "D2C, FMCG, fintech, consumer tech", fomo: "Signal you are a serious marketing client" },
  ];

  const agencyCategories = CATEGORIES.agency.subcategories.slice(0, 4).map(g => g.items.slice(0, 2)).flat().slice(0, 6);
  const creatorCategories = CATEGORIES.creator.subcategories.slice(0, 2).map(g => g.items.slice(0, 2)).flat().slice(0, 6);

  return (
    <WireframeShell screenId={1} screenName="Homepage" onApprove={onApprove} onRequestChange={onRequestChange} approved={approved}>

      {/* BROWSER CHROME */}
      <div style={{ backgroundColor: "#1a1a1a", padding: "8px 16px", display: "flex", alignItems: "center", gap: 8, borderBottom: "1px solid #222" }}>
        <div style={{ display: "flex", gap: 5 }}>
          {["#ff5f57","#ffbd2e","#28c840"].map(c => (
            <div key={c} style={{ width: 10, height: 10, borderRadius: "50%", backgroundColor: c }} />
          ))}
        </div>
        <div style={{ flex: 1, backgroundColor: "#111", borderRadius: 4, padding: "4px 12px", color: "#555", fontSize: 11, maxWidth: 400, margin: "0 auto" }}>
          fewfound.co
        </div>
      </div>

      {/* NAV */}
      <div style={{ backgroundColor: "#F4F1E8", borderBottom: "1px solid #DDD9CC", padding: "12px 40px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ position: "relative", display: "flex", alignItems: "center", gap: 2 }}>
          <div style={{ display: "flex", flexDirection: "column", lineHeight: 1 }}>
            <span style={{ fontFamily: "Georgia, serif", fontSize: 11, letterSpacing: "0.3em", fontWeight: 700, color: "#060608" }}>FEW</span>
            <div style={{ height: 1, backgroundColor: "#C4900A", margin: "2px 0" }} />
            <span style={{ fontFamily: "Georgia, serif", fontSize: 11, letterSpacing: "0.3em", fontWeight: 900, color: "#060608" }}>FOUND</span>
          </div>
          <Annotation number="1" text="Wordmark: FEW (bold serif), gold rule (#C4900A), FOUND (heavy serif). Reproduced exactly per brand spec. Gold appears ONLY here." />
        </div>

        <div style={{ display: "flex", gap: 28, alignItems: "center" }}>
          {["Agencies", "Creators", "Professionals", "Brands", "How it works"].map(item => (
            <span key={item} style={{ fontSize: 12, color: "#6B6A6D", cursor: "pointer", fontFamily: "Arial, sans-serif" }}>
              {item}
            </span>
          ))}
        </div>

        <div style={{ display: "flex", gap: 10, alignItems: "center", position: "relative" }}>
          <button style={{ backgroundColor: "transparent", border: "1px solid #060608", color: "#060608", padding: "6px 14px", fontSize: 11, cursor: "pointer", fontFamily: "Arial, sans-serif" }}>
            For brands
          </button>
          <button style={{ backgroundColor: "#060608", color: "#F4F1E8", border: "none", padding: "6px 14px", fontSize: 11, cursor: "pointer", fontFamily: "Arial, sans-serif" }}>
            List your profile
          </button>
          <Annotation number="2" text="Two CTAs. 'For brands' = secondary outline. 'List your profile' = primary filled black. Brand CTA links to /for-brands membership page. List links to type selection." />
        </div>
      </div>

      {/* HERO */}
      <div style={{ backgroundColor: "#060608", padding: "72px 40px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontFamily: "Georgia, serif", fontSize: 72, fontWeight: 700, color: "#F4F1E8", letterSpacing: "0.3em", lineHeight: 1 }}>FEW</div>
            <div style={{ height: 2, backgroundColor: "#C4900A", maxWidth: 520, margin: "8px 0" }} />
            <div style={{ fontFamily: "Georgia, serif", fontSize: 72, fontWeight: 900, color: "#F4F1E8", letterSpacing: "0.3em", lineHeight: 1 }}>FOUND</div>
          </div>

          <div style={{ position: "relative", display: "inline-block" }}>
            <p style={{ fontFamily: "Georgia, serif", fontSize: 22, color: "rgba(244,241,232,0.8)", maxWidth: 560, lineHeight: 1.5, marginBottom: 8 }}>
              India's trust layer for marketing service providers.
            </p>
            <Annotation number="3" text="H1 tagline. Georgia serif. Not a slogan — a category definition. This is what AI search tools will cite when describing what Few Found is." />
          </div>

          <p style={{ fontFamily: "Arial, sans-serif", fontSize: 14, color: "rgba(244,241,232,0.45)", maxWidth: 480, lineHeight: 1.7, marginBottom: 40, marginTop: 8 }}>
            The brands making the best hiring decisions are already here — searching for verified agencies, creators, and professionals. The question is whether they will find you.
          </p>

          {/* 4 CTAs */}
          <div style={{ position: "relative", display: "inline-block" }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, maxWidth: 820 }}>
              {types.map(type => (
                <div
                  key={type.id}
                  onMouseEnter={() => setHoveredType(type.id)}
                  onMouseLeave={() => setHoveredType(null)}
                  style={{
                    border: `1px solid ${hoveredType === type.id ? "rgba(244,241,232,0.5)" : "rgba(244,241,232,0.12)"}`,
                    padding: "16px 14px", cursor: "pointer",
                    transition: "border-color 0.2s",
                  }}
                >
                  <p style={{ fontFamily: "Arial, sans-serif", fontSize: 12, color: "#F4F1E8", fontWeight: 600, marginBottom: 6 }}>
                    {type.label} →
                  </p>
                  <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "rgba(244,241,232,0.35)", lineHeight: 1.5, marginBottom: 8 }}>
                    {type.desc}
                  </p>
                  <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#C4900A", fontStyle: "italic" }}>
                    {type.fomo}
                  </p>
                </div>
              ))}
            </div>
            <div style={{ position: "absolute", top: -24, right: -30 }}>
              <Annotation number="4" text="4 CTA cards in hero. Each shows type, description, and FOMO line in gold. Clicking any goes to type selection screen (Screen 2). Gold FOMO text is the only gold element besides the wordmark rule." />
            </div>
          </div>
        </div>
      </div>

      {/* FOMO TICKER */}
      <div style={{ backgroundColor: "#0a0a0a", borderBottom: "1px solid #111", padding: "8px 40px" }}>
        <div style={{ position: "relative", display: "inline-block" }}>
          <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "rgba(244,241,232,0.3)", letterSpacing: "0.1em", textAlign: "center" }}>
            BRANDS ON THE PLATFORM ARE ACTIVELY SHORTLISTING VERIFIED PROVIDERS &nbsp;·&nbsp; LISTED-ONLY PROVIDERS DO NOT APPEAR IN BRAND SHORTLISTS &nbsp;·&nbsp; VERIFICATION APPLICATIONS BEING PROCESSED NOW
          </p>
          <Annotation number="5" text="Static FOMO ticker. No animation for now — adds complexity. Can be animated later. Text updates weekly via CMS. Creates urgency without being aggressive." />
        </div>
      </div>

      {/* SEARCH BAR */}
      <div style={{ backgroundColor: "#F4F1E8", borderBottom: "1px solid #DDD9CC", padding: "24px 40px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ position: "relative", display: "flex", gap: 0, marginBottom: 8 }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10 }}>
              Search & verify — see who is verified and who is not
            </p>
            <Annotation number="6" text="Search label explicitly says 'verify'. Positioning is demand-side: brands use this to check if what agencies claim is real. Not just a discovery tool." />
          </div>
          <div style={{ display: "flex" }}>
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setSearchFocused(false)}
              placeholder="Search any agency, creator, or professional — see who is verified and who is not..."
              style={{
                flex: 1, backgroundColor: "#F4F1E8",
                border: `1px solid ${searchFocused ? "#060608" : "#DDD9CC"}`,
                borderRight: "none", color: "#060608",
                fontFamily: "Arial, sans-serif", fontSize: 14,
                padding: "12px 16px", outline: "none",
                transition: "border-color 0.15s",
              }}
            />
            <button style={{
              backgroundColor: "#060608", color: "#F4F1E8",
              border: "none", padding: "12px 28px",
              fontSize: 13, cursor: "pointer", fontWeight: 500,
              fontFamily: "Arial, sans-serif", whiteSpace: "nowrap",
            }}>
              Search
            </button>
          </div>
          <p style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#6B6A6D", marginTop: 6 }}>
            Brands: search any name to see their independent verification status and score band.
          </p>
        </div>
      </div>

      {/* STATS */}
      <div style={{ backgroundColor: "#F4F1E8", borderBottom: "1px solid #DDD9CC" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 40px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderTop: "1px solid #DDD9CC", borderLeft: "1px solid #DDD9CC" }}>
            {[
              { value: stats.listed, label: "Providers listed" },
              { value: stats.verified, label: "Verified — appearing first in every search" },
              { value: stats.brands, label: "Brands searching for partners" },
            ].map((stat, i) => (
              <div key={i} style={{ textAlign: "center", padding: "28px 20px", borderRight: "1px solid #DDD9CC", borderBottom: "1px solid #DDD9CC", position: "relative" }}>
                <p style={{ fontFamily: "Georgia, serif", fontSize: 48, color: "#060608", margin: 0, lineHeight: 1 }}>
                  {stat.value}
                </p>
                <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 8 }}>
                  {stat.label}
                </p>
                {i === 1 && (
                  <div style={{ position: "absolute", top: 8, right: 8 }}>
                    <Annotation number="7" text="Stats pulled live from Supabase. Not hardcoded. Updates every page load. If database empty at launch, shows seed data counts. Never shows 0." />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CLAIM CHECKER SECTION */}
      <div style={{ backgroundColor: "#F0EDE4", borderBottom: "1px solid #DDD9CC" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "56px 40px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, alignItems: "center" }}>
            <div>
              <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>
                For brands & buyers
              </p>
              <h2 style={{ fontFamily: "Georgia, serif", fontSize: 32, color: "#060608", lineHeight: 1.2, marginBottom: 16 }}>
                Search any agency.<br />See what we actually found.
              </h2>
              <p style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "#6B6A6D", lineHeight: 1.7, marginBottom: 16 }}>
                An agency tells you they worked with Myntra. Search them on Few Found. See whether that claim is independently verified — or just a name on a pitch deck. Free to search.
              </p>
              <p style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "#6B6A6D", lineHeight: 1.7, marginBottom: 24 }}>
                Brand members get the full picture: score bands, reference contacts, evidence packs.
              </p>
              <div style={{ display: "flex", gap: 10 }}>
                <button style={{ backgroundColor: "#060608", color: "#F4F1E8", border: "none", padding: "10px 20px", fontSize: 12, cursor: "pointer", fontFamily: "Arial, sans-serif" }}>
                  Search verified agencies
                </button>
                <button style={{ backgroundColor: "transparent", color: "#060608", border: "1px solid #060608", padding: "10px 20px", fontSize: 12, cursor: "pointer", fontFamily: "Arial, sans-serif" }}>
                  Brand membership →
                </button>
              </div>
            </div>

            <div>
              <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 12 }}>
                What verification actually checks
              </p>
              <div style={{ position: "relative" }}>
                {[
                  { claim: "We worked with Nykaa", verified: true, note: "Reference contacted. Confirmed." },
                  { claim: "We drove 400% ROAS for a D2C brand", verified: false, note: "Not verified. Evidence not submitted." },
                  { claim: "Team of 40 specialists", verified: true, note: "LinkedIn headcount cross-referenced. Confirmed." },
                  { claim: "Founded in 2015", verified: true, note: "MCA registration date confirmed." },
                  { claim: "Won three industry awards", verified: false, note: "Not verified. Listed only." },
                ].map((item, i) => (
                  <div key={i} style={{
                    display: "flex", alignItems: "flex-start", gap: 10,
                    padding: "12px 14px", backgroundColor: "#F4F1E8",
                    border: "1px solid #DDD9CC", marginBottom: 4,
                  }}>
                    <div style={{
                      width: 18, height: 18, flexShrink: 0,
                      backgroundColor: item.verified ? "#060608" : "transparent",
                      border: item.verified ? "none" : "1px solid #DDD9CC",
                      display: "flex", alignItems: "center", justifyContent: "center",
                    }}>
                      {item.verified
                        ? <span style={{ color: "#F4F1E8", fontSize: 9, fontWeight: 700 }}>✓</span>
                        : <span style={{ color: "#6B6A6D", fontSize: 9 }}>✗</span>
                      }
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontFamily: "Arial, sans-serif", fontSize: 12, color: "#060608", margin: 0 }}>{item.claim}</p>
                      <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", margin: 0 }}>{item.note}</p>
                    </div>
                    <span style={{
                      fontSize: 9, padding: "2px 8px", letterSpacing: "0.08em", flexShrink: 0,
                      backgroundColor: item.verified ? "#060608" : "transparent",
                      color: item.verified ? "#F4F1E8" : "#6B6A6D",
                      border: item.verified ? "none" : "1px solid #DDD9CC",
                    }}>
                      {item.verified ? "VERIFIED" : "LISTED"}
                    </span>
                  </div>
                ))}
                <div style={{ position: "absolute", top: -20, right: 0 }}>
                  <Annotation number="8" text="Claim checker illustration. These are static examples on homepage. The real version is dynamic — when a brand searches a real agency, their actual verified/unverified claims appear. This section educates on what verification checks." />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* HOW IT WORKS */}
      <div style={{ backgroundColor: "#F4F1E8", borderBottom: "1px solid #DDD9CC" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "56px 40px" }}>
          <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 36 }}>
            How it works
          </p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 40 }}>
            {[
              { step: "01", title: "List free. Today.", body: "Profile goes live the moment you submit. No approval queue. Discoverable from minute one." },
              { step: "02", title: "Apply for verification.", body: "Submit references and evidence. We contact references independently. Fully automated. Results in 5 to 7 days." },
              { step: "03", title: "Get found ahead of everyone who did not bother.", body: "Verified providers appear above listed-only in every search. Always. Permanently." },
            ].map((step, i) => (
              <div key={i}>
                <p style={{ fontFamily: "Georgia, serif", fontSize: 48, color: "rgba(6,6,8,0.1)", marginBottom: 16 }}>{step.step}</p>
                <h3 style={{ fontFamily: "Georgia, serif", fontSize: 18, color: "#060608", marginBottom: 10 }}>{step.title}</h3>
                <p style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "#6B6A6D", lineHeight: 1.6 }}>{step.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CATEGORY GRID */}
      <div style={{ backgroundColor: "#F4F1E8", borderBottom: "1px solid #DDD9CC" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "56px 40px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 36 }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase" }}>
              Browse verified providers
            </p>
            <div style={{ position: "relative" }}>
              <Annotation number="9" text="Category grid links to category pages. If a category has zero verified providers, the page shows an empty state: 'Our system is working in the background. Come back soon.' Never a dead page." />
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                <h3 style={{ fontFamily: "Georgia, serif", fontSize: 16, color: "#060608" }}>Agencies</h3>
                <span style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D" }}>Verified first. Always.</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                {agencyCategories.map(cat => (
                  <div key={cat} style={{
                    fontFamily: "Arial, sans-serif", fontSize: 12, color: "#6B6A6D",
                    padding: "6px 0", borderBottom: "1px solid #EEE9DC",
                    cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
                  }}>
                    <span style={{ width: 4, height: 4, backgroundColor: "#DDD9CC", borderRadius: "50%", flexShrink: 0 }} />
                    {cat}
                  </div>
                ))}
                <div style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#C4900A", padding: "6px 0", cursor: "pointer" }}>
                  + {CATEGORIES.agency.subcategories.reduce((a,g) => a + g.items.length, 0) - agencyCategories.length} more categories
                </div>
              </div>
            </div>

            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                <h3 style={{ fontFamily: "Georgia, serif", fontSize: 16, color: "#060608" }}>Creators</h3>
                <span style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D" }}>Commercially verified. Not just followed.</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
                {creatorCategories.map(cat => (
                  <div key={cat} style={{
                    fontFamily: "Arial, sans-serif", fontSize: 12, color: "#6B6A6D",
                    padding: "6px 0", borderBottom: "1px solid #EEE9DC",
                    cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
                  }}>
                    <span style={{ width: 4, height: 4, backgroundColor: "#DDD9CC", borderRadius: "50%", flexShrink: 0 }} />
                    {cat}
                  </div>
                ))}
                <div style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#C4900A", padding: "6px 0", cursor: "pointer" }}>
                  + {CATEGORIES.creator.subcategories.reduce((a,g) => a + g.items.length, 0) - creatorCategories.length} more categories
                </div>
              </div>
            </div>
          </div>

          {/* City grid */}
          <div style={{ marginTop: 40, paddingTop: 32, borderTop: "1px solid #DDD9CC" }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 16 }}>
              Browse by city
            </p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {["Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Pune", "Kolkata", "Ahmedabad", "Jaipur", "Gurugram"].map(city => (
                <div key={city} style={{
                  fontFamily: "Arial, sans-serif", fontSize: 12, color: "#6B6A6D",
                  border: "1px solid #DDD9CC", padding: "6px 16px", cursor: "pointer",
                }}>
                  {city}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* FOMO CLOSER */}
      <div style={{ backgroundColor: "#060608" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "56px 40px" }}>
          <div style={{ maxWidth: 640, position: "relative" }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "rgba(244,241,232,0.25)", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }}>
              The reality
            </p>
            <h2 style={{ fontFamily: "Georgia, serif", fontSize: 36, color: "#F4F1E8", lineHeight: 1.2, marginBottom: 20 }}>
              Every day you are not verified, a brand that searched for you found someone who was.
            </h2>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "rgba(244,241,232,0.4)", lineHeight: 1.7, marginBottom: 28 }}>
              Listing is free. Four minutes. Verified providers appear above listed-only providers in every search, every time, permanently.
            </p>
            <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
              <button style={{ backgroundColor: "#F4F1E8", color: "#060608", border: "none", padding: "12px 24px", fontSize: 13, cursor: "pointer", fontWeight: 600, fontFamily: "Arial, sans-serif" }}>
                List your profile free
              </button>
              <span style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "rgba(244,241,232,0.4)", textDecoration: "underline", cursor: "pointer" }}>
                Apply for verification →
              </span>
            </div>
            <div style={{ position: "absolute", top: 0, right: -40 }}>
              <Annotation number="10" position="left" text="FOMO closer on dark background. H2 is the strongest FOMO statement on the page. Two CTAs: primary (list free) and ghost (verify). This section appears only for non-logged-in users. Logged-in users see their dashboard prompt instead." />
            </div>
          </div>
        </div>
      </div>

      {/* THE RULE */}
      <div style={{ backgroundColor: "#F4F1E8" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "56px 40px" }}>
          <div style={{ maxWidth: 640 }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 20 }}>
              The one rule
            </p>
            <blockquote style={{ fontFamily: "Georgia, serif", fontSize: 20, color: "#060608", lineHeight: 1.6, borderLeft: "3px solid #060608", paddingLeft: 20, margin: 0 }}>
              Verified providers always appear above listed-only providers in every search result. No provider can pay to appear higher. No sponsored results. No featured placement. Ever.
            </blockquote>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 12, color: "#6B6A6D", marginTop: 16 }}>
              Hardcoded into the database query. Cannot be changed from any admin panel.
            </p>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={{ backgroundColor: "#F4F1E8", borderTop: "1px solid #DDD9CC" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "48px 40px" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 40, marginBottom: 40 }}>
            <div>
              <div style={{ display: "flex", flexDirection: "column", lineHeight: 1, marginBottom: 12 }}>
                <span style={{ fontFamily: "Georgia, serif", fontSize: 10, letterSpacing: "0.3em", fontWeight: 700, color: "#060608" }}>FEW</span>
                <div style={{ height: 1, backgroundColor: "#C4900A", margin: "2px 0", width: 28 }} />
                <span style={{ fontFamily: "Georgia, serif", fontSize: 10, letterSpacing: "0.3em", fontWeight: 900, color: "#060608" }}>FOUND</span>
              </div>
              <p style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#6B6A6D", lineHeight: 1.6 }}>
                India's trust layer for marketing service providers.
              </p>
            </div>
            {[
              { title: "Browse", links: ["All agencies", "All creators", "All professionals", "Brand partners"] },
              { title: "Cities", links: ["Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Pune"] },
              { title: "Company", links: ["About", "How it works", "Verification standards", "For brands", "List your profile"] },
            ].map(col => (
              <div key={col.title}>
                <p style={{ fontFamily: "Arial, sans-serif", fontSize: 10, color: "#6B6A6D", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 16 }}>
                  {col.title}
                </p>
                {col.links.map(link => (
                  <p key={link} style={{ fontFamily: "Arial, sans-serif", fontSize: 12, color: "#6B6A6D", marginBottom: 8, cursor: "pointer" }}>
                    {link}
                  </p>
                ))}
              </div>
            ))}
          </div>
          <div style={{ borderTop: "1px solid #DDD9CC", paddingTop: 20, display: "flex", justifyContent: "space-between" }}>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#6B6A6D" }}>
              © 2026 Few Found. All rights reserved.
            </p>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 11, color: "#6B6A6D" }}>
              Verified providers are independently assessed. Few Found does not accept payment for placement.
            </p>
          </div>
        </div>
      </div>

      {/* Spacer for bottom bar */}
      <div style={{ height: 70 }} />
    </WireframeShell>
  );
}

// ─── SCREEN MAP SIDEBAR ───────────────────────────────────────────────────
function ScreenMap({ currentScreen, approvedScreens }) {
  return (
    <div style={{
      position: "fixed", right: 0, top: 0, bottom: 0,
      width: 220, backgroundColor: "#0d0d0d", borderLeft: "1px solid #1a1a1a",
      overflowY: "auto", zIndex: 400, padding: "16px 0",
    }}>
      <div style={{ padding: "0 16px 16px", borderBottom: "1px solid #1a1a1a" }}>
        <p style={{ color: "#FF6B35", fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", fontFamily: "monospace" }}>
          SCREEN MAP
        </p>
        <p style={{ color: "#333", fontSize: 9, fontFamily: "monospace" }}>
          {approvedScreens.length} / {SCREENS.length} approved
        </p>
      </div>
      {SCREENS.map(screen => (
        <div key={screen.id} style={{
          padding: "8px 16px", display: "flex", alignItems: "center", gap: 8,
          backgroundColor: currentScreen === screen.id ? "#1a1a1a" : "transparent",
          borderLeft: currentScreen === screen.id ? "2px solid #FF6B35" : "2px solid transparent",
        }}>
          <div style={{
            width: 14, height: 14, borderRadius: "50%", flexShrink: 0,
            backgroundColor: approvedScreens.includes(screen.id) ? "#4ade80"
              : currentScreen === screen.id ? "#FF6B35" : "#222",
            border: approvedScreens.includes(screen.id) ? "none"
              : currentScreen === screen.id ? "none" : "1px solid #333",
          }} />
          <p style={{
            fontFamily: "monospace", fontSize: 9,
            color: currentScreen === screen.id ? "#ccc"
              : approvedScreens.includes(screen.id) ? "#4ade80" : "#444",
            lineHeight: 1.4,
          }}>
            {screen.id}. {screen.name}
          </p>
        </div>
      ))}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────
export default function WireframeSystem() {
  const [currentScreen, setCurrentScreen] = useState(1);
  const [approvedScreens, setApprovedScreens] = useState([]);
  const [changeRequests, setChangeRequests] = useState([]);
  const [showSidebar, setShowSidebar] = useState(true);

  function handleApprove() {
    setApprovedScreens(prev => [...prev, currentScreen]);
    if (currentScreen < SCREENS.length) {
      setTimeout(() => setCurrentScreen(currentScreen + 1), 300);
    }
  }

  function handleRequestChange(note) {
    setChangeRequests(prev => [...prev, { screen: currentScreen, note, timestamp: new Date().toLocaleTimeString() }]);
    alert(`Change request logged for Screen ${currentScreen}:\n\n"${note}"\n\nThis will be addressed in the next revision.`);
  }

  const isApproved = approvedScreens.includes(currentScreen);

  return (
    <div style={{ marginRight: showSidebar ? 220 : 0 }}>
      {currentScreen === 1 && (
        <Screen1Homepage
          onApprove={handleApprove}
          onRequestChange={handleRequestChange}
          approved={isApproved}
        />
      )}

      {currentScreen > 1 && (
        <WireframeShell
          screenId={currentScreen}
          screenName={SCREENS[currentScreen - 1]?.name}
          onApprove={handleApprove}
          onRequestChange={handleRequestChange}
          approved={isApproved}
        >
          <div style={{ backgroundColor: "#F4F1E8", minHeight: "80vh", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 16 }}>
            <p style={{ fontFamily: "Georgia, serif", fontSize: 28, color: "#060608" }}>
              Screen {currentScreen}: {SCREENS[currentScreen - 1]?.name}
            </p>
            <p style={{ fontFamily: "Arial, sans-serif", fontSize: 13, color: "#6B6A6D" }}>
              Approve Screen {currentScreen - 1} first to build this screen.
            </p>
            <button
              onClick={() => setCurrentScreen(currentScreen - 1)}
              style={{ backgroundColor: "#060608", color: "#F4F1E8", border: "none", padding: "10px 20px", fontSize: 12, cursor: "pointer", fontFamily: "Arial, sans-serif" }}
            >
              ← Back to Screen {currentScreen - 1}
            </button>
          </div>
        </WireframeShell>
      )}

      {showSidebar && (
        <ScreenMap currentScreen={currentScreen} approvedScreens={approvedScreens} />
      )}

      {/* Sidebar toggle */}
      <button
        onClick={() => setShowSidebar(!showSidebar)}
        style={{
          position: "fixed", right: showSidebar ? 228 : 8, top: 60,
          backgroundColor: "#1a1a1a", color: "#555", border: "1px solid #222",
          padding: "4px 8px", fontSize: 10, cursor: "pointer",
          fontFamily: "monospace", zIndex: 600,
        }}
      >
        {showSidebar ? "▶" : "◀"}
      </button>
    </div>
  );
}
